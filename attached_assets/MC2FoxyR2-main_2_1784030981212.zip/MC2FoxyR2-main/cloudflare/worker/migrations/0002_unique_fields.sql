-- Migration: unique-field enforcement for records collections.
-- Adds two tables:
--   collection_schemas  — stores which fields must be unique per collection
--   record_unique_values — stores actual field values with a UNIQUE constraint
--                          so concurrent inserts can never produce duplicates

CREATE TABLE IF NOT EXISTS collection_schemas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  collection TEXT NOT NULL,
  -- JSON array of field names that must be unique within the collection,
  -- e.g. '["customId"]' or '["username"]'
  unique_fields TEXT NOT NULL DEFAULT '[]',
  UNIQUE(project_id, collection)
);

CREATE TABLE IF NOT EXISTS record_unique_values (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  collection TEXT NOT NULL,
  field_name TEXT NOT NULL,
  field_value TEXT NOT NULL,
  record_id INTEGER NOT NULL REFERENCES records(id) ON DELETE CASCADE,
  -- The real uniqueness guard: two records in the same project+collection
  -- cannot share the same value for the same declared-unique field.
  UNIQUE(project_id, collection, field_name, field_value)
);

CREATE INDEX IF NOT EXISTS idx_ruv_record ON record_unique_values(record_id);
