import { randomBytes, createHash, createHmac, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

// Identical logic to artifacts/api-server/src/lib/crypto.ts — ported as-is
// because Cloudflare Workers' `nodejs_compat` flag supports node:crypto,
// including scrypt/timingSafeEqual, so no Web Crypto rewrite is needed.

const scryptAsync = promisify(scrypt);

export function hashApiKeySecret(secret: string): string {
  return createHash("sha256").update(secret).digest("hex");
}

export function generateApiKey(): { keyPrefix: string; secret: string } {
  const raw = randomBytes(24).toString("base64url");
  const secret = `bk_live_${raw}`;
  const keyPrefix = secret.slice(0, 14);
  return { keyPrefix, secret };
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [salt, hashHex] = stored.split(":");
  if (!salt || !hashHex) return false;
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  const storedBuf = Buffer.from(hashHex, "hex");
  if (derived.length !== storedBuf.length) return false;
  return timingSafeEqual(derived, storedBuf);
}

/**
 * Signs a short-lived upload token for a specific R2 object key.
 * The token is HMAC-SHA256(key + ":" + hourSlot, SESSION_SECRET), encoded as
 * base64url — valid for the current hour and the previous hour (edge boundary).
 *
 * This replaces open-to-world PUT /storage/objects/:key: only a caller who
 * obtained an uploadURL from the authenticated /v1/storage/upload endpoint can
 * produce the correct token for that UUID key.
 */
export function signUploadToken(key: string, secret: string): string {
  const hourSlot = Math.floor(Date.now() / 3_600_000);
  return createHmac("sha256", secret).update(`${key}:${hourSlot}`).digest("base64url");
}

export function verifyUploadToken(key: string, token: string, secret: string): boolean {
  const now = Math.floor(Date.now() / 3_600_000);
  for (const slot of [now, now - 1]) {
    const expected = createHmac("sha256", secret).update(`${key}:${slot}`).digest("base64url");
    try {
      const a = Buffer.from(token);
      const b = Buffer.from(expected);
      if (a.length === b.length && timingSafeEqual(a, b)) return true;
    } catch {
      // length mismatch — not equal
    }
  }
  return false;
}
