import { Hono } from "hono";
import { eq, and } from "drizzle-orm";
import { z } from "zod";
import { apiKeyAuth } from "../middlewares/apiKeyAuth";
import { requireAuth } from "../middlewares/requireAuth";
import { getDb, getProjectId, loadOwnedProject, parseId } from "../lib/context";
import { collectionSchemasTable } from "../schema";
import type { AppEnv } from "../types";

// ── Public API routes (apiKeyAuth) ─────────────────────────────────────────
// Called by end-user code via X-API-Key.
export const publicCollectionsRouter = new Hono<AppEnv>();
publicCollectionsRouter.use(apiKeyAuth);

const SchemaBody = z.object({
  uniqueFields: z
    .array(z.string().regex(/^[a-zA-Z0-9_]+$/, "Field names must be alphanumeric/underscore"))
    .default([]),
});

// PUT /v1/collections/:collection/schema — create or replace the unique-field list
publicCollectionsRouter.put("/v1/collections/:collection/schema", async (c) => {
  const collection = c.req.param("collection");
  const projectId = getProjectId(c);

  const parsed = SchemaBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const db = getDb(c);
  await db
    .insert(collectionSchemasTable)
    .values({ projectId, collection, uniqueFields: parsed.data.uniqueFields })
    .onConflictDoUpdate({
      target: [collectionSchemasTable.projectId, collectionSchemasTable.collection],
      set: { uniqueFields: parsed.data.uniqueFields },
    });

  return c.json({ collection, uniqueFields: parsed.data.uniqueFields });
});

// GET /v1/collections/:collection/schema — read the schema (returns empty uniqueFields if unset)
publicCollectionsRouter.get("/v1/collections/:collection/schema", async (c) => {
  const collection = c.req.param("collection");
  const projectId = getProjectId(c);
  const db = getDb(c);

  const [row] = await db
    .select()
    .from(collectionSchemasTable)
    .where(and(eq(collectionSchemasTable.projectId, projectId), eq(collectionSchemasTable.collection, collection)))
    .limit(1);

  return c.json({ collection, uniqueFields: row?.uniqueFields ?? [] });
});

// ── Dashboard routes (requireAuth) ─────────────────────────────────────────
// Called by the BaaS dashboard on behalf of the logged-in developer.
export const dashboardCollectionsRouter = new Hono<AppEnv>();
dashboardCollectionsRouter.use(requireAuth);

// GET /projects/:projectId/collections — list all collections that have a schema
dashboardCollectionsRouter.get("/projects/:projectId/collections", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const db = getDb(c);
  const rows = await db
    .select()
    .from(collectionSchemasTable)
    .where(eq(collectionSchemasTable.projectId, project.id));

  return c.json(rows.map((r) => ({ collection: r.collection, uniqueFields: r.uniqueFields })));
});

// PUT /projects/:projectId/collections/:collection/schema
dashboardCollectionsRouter.put("/projects/:projectId/collections/:collection/schema", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const collection = c.req.param("collection");
  const parsed = SchemaBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const db = getDb(c);
  await db
    .insert(collectionSchemasTable)
    .values({ projectId: project.id, collection, uniqueFields: parsed.data.uniqueFields })
    .onConflictDoUpdate({
      target: [collectionSchemasTable.projectId, collectionSchemasTable.collection],
      set: { uniqueFields: parsed.data.uniqueFields },
    });

  return c.json({ collection, uniqueFields: parsed.data.uniqueFields });
});

// GET /projects/:projectId/collections/:collection/schema
dashboardCollectionsRouter.get("/projects/:projectId/collections/:collection/schema", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const collection = c.req.param("collection");
  const db = getDb(c);

  const [row] = await db
    .select()
    .from(collectionSchemasTable)
    .where(
      and(
        eq(collectionSchemasTable.projectId, project.id),
        eq(collectionSchemasTable.collection, collection),
      ),
    )
    .limit(1);

  return c.json({ collection, uniqueFields: row?.uniqueFields ?? [] });
});
