import { Hono } from "hono";
import type { Context } from "hono";
import { eq, and, asc, desc, sql, count as countFn } from "drizzle-orm";
import {
  CreatePublicRecordBody,
  CreatePublicRecordResponse,
  GetPublicRecordResponse,
  UpdatePublicRecordBody,
  UpdatePublicRecordResponse,
  IncrementPublicRecordFieldBody,
  IncrementPublicRecordFieldResponse,
} from "@workspace/api-zod";
import { recordsTable, collectionSchemasTable, recordUniqueValuesTable } from "../schema";
import { apiKeyAuth } from "../middlewares/apiKeyAuth";
import { verifyEndUserToken } from "../lib/endUserToken";
import { getDb, getProjectId, parseId, bearerToken } from "../lib/context";
import type { AppEnv } from "../types";

export const publicDataRouter = new Hono<AppEnv>();
publicDataRouter.use(apiKeyAuth);

// SQLite's json_extract()/json_set() take the JSON path as a normal bound
// parameter (unlike Postgres's `->>` operator, which needs the field name
// embedded in SQL syntax) — so field names are never spliced into raw SQL.
// This check is just to keep path syntax well-formed, not for SQL-injection
// defense.
const FIELD_NAME_RE = /^[a-zA-Z0-9_]+$/;

function getCollectionParam(c: Context<AppEnv>): string {
  const collection = c.req.param("collection");
  if (!collection) throw new Error("collection route param missing");
  return collection;
}

async function loadScopedRecord(c: Context<AppEnv>) {
  const db = getDb(c);
  const recordId = parseId(c.req.param("recordId"));
  const [row] = await db
    .select()
    .from(recordsTable)
    .where(
      and(
        eq(recordsTable.id, recordId),
        eq(recordsTable.projectId, getProjectId(c)),
        eq(recordsTable.collection, getCollectionParam(c)),
      ),
    )
    .limit(1);
  return row;
}

/** Load the unique-field list for a collection, returns [] when none defined. */
async function loadUniqueFields(
  db: ReturnType<typeof getDb>,
  projectId: number,
  collection: string,
): Promise<string[]> {
  const [schema] = await db
    .select({ uniqueFields: collectionSchemasTable.uniqueFields })
    .from(collectionSchemasTable)
    .where(
      and(
        eq(collectionSchemasTable.projectId, projectId),
        eq(collectionSchemasTable.collection, collection),
      ),
    )
    .limit(1);
  return (schema?.uniqueFields as string[]) ?? [];
}

/** Returns the field name that caused a UNIQUE conflict, or null on success. */
function parseUniqueConflictField(err: unknown, fields: string[]): string | null {
  const msg = err instanceof Error ? err.message : String(err);
  if (!msg.includes("UNIQUE constraint failed") && !msg.toLowerCase().includes("unique")) return null;
  // D1 error format: "UNIQUE constraint failed: record_unique_values.project_id, ..."
  for (const field of fields) {
    if (msg.includes(field)) return field;
  }
  return fields[0] ?? "unknown";
}

// GET /v1/data/:collection
// Query params: limit, offset, orderBy (createdAt|updatedAt|data.<field>), order (asc/desc),
// where.<field>=<value>, ownedBy=me (requires an end-user bearer token)
publicDataRouter.get("/v1/data/:collection", async (c) => {
  const projectId = getProjectId(c);
  const collection = c.req.param("collection");
  const db = getDb(c);

  const limit = Math.min(parseInt(c.req.query("limit") ?? "50", 10) || 50, 500);
  const offset = parseInt(c.req.query("offset") ?? "0", 10) || 0;
  const orderField = c.req.query("orderBy") ?? "createdAt";
  const orderDir = (c.req.query("order") ?? "desc").toLowerCase() === "asc" ? "asc" : "desc";
  const dataOrderField = orderField.startsWith("data.") ? orderField.slice(5) : undefined;

  if (!collection) return c.json({ error: "collection route param missing" }, 400);

  const conditions = [eq(recordsTable.projectId, projectId), eq(recordsTable.collection, collection)];

  for (const [key, value] of Object.entries(c.req.query())) {
    if (key.startsWith("where.")) {
      const field = key.slice(6);
      if (!FIELD_NAME_RE.test(field)) return c.json({ error: `Invalid filter field: ${field}` }, 400);
      conditions.push(sql`json_extract(${recordsTable.data}, ${"$." + field}) = ${value}`);
    }
  }

  if (c.req.query("ownedBy") === "me") {
    const token = bearerToken(c);
    if (!token) return c.json({ error: "Authorization token required for ownedBy=me" }, 401);
    const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
    if (!payload || payload.projectId !== projectId) {
      return c.json({ error: "Invalid token for ownership filter" }, 401);
    }
    conditions.push(sql`json_extract(${recordsTable.data}, '$._ownerId') = ${String(payload.endUserId)}`);
  }

  let orderExpr;
  if (dataOrderField) {
    if (!FIELD_NAME_RE.test(dataOrderField)) return c.json({ error: `Invalid orderBy field: ${dataOrderField}` }, 400);
    const expr = sql`CAST(json_extract(${recordsTable.data}, ${"$." + dataOrderField}) AS REAL)`;
    orderExpr = orderDir === "asc" ? asc(expr) : desc(expr);
  } else if (orderField === "updatedAt") {
    orderExpr = orderDir === "asc" ? asc(recordsTable.updatedAt) : desc(recordsTable.updatedAt);
  } else {
    orderExpr = orderDir === "asc" ? asc(recordsTable.createdAt) : desc(recordsTable.createdAt);
  }

  const rows = await db.select().from(recordsTable).where(and(...conditions)).orderBy(orderExpr).limit(limit).offset(offset);
  const [{ value: total }] = await db.select({ value: countFn() }).from(recordsTable).where(and(...conditions));

  return c.json({ data: rows, total, limit, offset });
});

// POST /v1/data/:collection — if Authorization header present, auto-sets _ownerId in data.
// Enforces unique fields declared via PUT /v1/collections/:collection/schema.
publicDataRouter.post("/v1/data/:collection", async (c) => {
  const parsed = CreatePublicRecordBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const projectId = getProjectId(c);
  const collection = getCollectionParam(c);
  const db = getDb(c);

  let ownerId: number | undefined;
  const token = bearerToken(c);
  if (token) {
    const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
    if (payload && payload.projectId === projectId) ownerId = payload.endUserId;
  }

  const data: Record<string, unknown> = { ...parsed.data.data };
  if (ownerId !== undefined) data._ownerId = String(ownerId);

  const uniqueFields = await loadUniqueFields(db, projectId, collection);

  try {
    const row = await db.transaction(async (tx) => {
      const [record] = await tx
        .insert(recordsTable)
        .values({ projectId, collection, data })
        .returning();

      // Insert a unique-value sentinel for each declared unique field.
      // The UNIQUE constraint on record_unique_values catches concurrent duplicates.
      for (const field of uniqueFields) {
        const value = data[field];
        if (value === undefined || value === null) continue;
        await tx.insert(recordUniqueValuesTable).values({
          projectId,
          collection,
          fieldName: field,
          fieldValue: String(value),
          recordId: record!.id,
        });
      }

      return record!;
    });

    return c.json(CreatePublicRecordResponse.parse(row), 201);
  } catch (e) {
    const field = parseUniqueConflictField(e, uniqueFields);
    if (field) return c.json({ error: `Duplicate value for unique field: ${field}` }, 409);
    throw e;
  }
});

publicDataRouter.get("/v1/data/:collection/:recordId", async (c) => {
  const row = await loadScopedRecord(c);
  if (!row) return c.json({ error: "Record not found" }, 404);
  return c.json(GetPublicRecordResponse.parse(row));
});

// PATCH — only owner can update their own record (if _ownerId set).
// Enforces unique fields on the merged result.
publicDataRouter.patch("/v1/data/:collection/:recordId", async (c) => {
  const existing = await loadScopedRecord(c);
  if (!existing) return c.json({ error: "Record not found" }, 404);

  const ownerId = (existing.data as Record<string, unknown>)._ownerId;
  if (ownerId !== undefined) {
    const token = bearerToken(c);
    if (!token) return c.json({ error: "Authorization token required to update this record" }, 401);
    const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
    if (!payload || String(payload.endUserId) !== String(ownerId)) return c.json({ error: "You do not own this record" }, 403);
  }

  const parsed = UpdatePublicRecordBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const projectId = getProjectId(c);
  const collection = getCollectionParam(c);
  const db = getDb(c);

  const uniqueFields = await loadUniqueFields(db, projectId, collection);
  const merged: Record<string, unknown> = { ...(existing.data as object), ...parsed.data.data };

  try {
    const row = await db.transaction(async (tx) => {
      // Remove this record's old unique-value sentinels so the new values can
      // be written fresh (and so a field can be changed without self-conflicting).
      if (uniqueFields.length > 0) {
        await tx.delete(recordUniqueValuesTable).where(eq(recordUniqueValuesTable.recordId, existing.id));
      }

      const [record] = await tx
        .update(recordsTable)
        .set({ data: merged, updatedAt: new Date() })
        .where(eq(recordsTable.id, existing.id))
        .returning();

      for (const field of uniqueFields) {
        const value = merged[field];
        if (value === undefined || value === null) continue;
        await tx.insert(recordUniqueValuesTable).values({
          projectId,
          collection,
          fieldName: field,
          fieldValue: String(value),
          recordId: record!.id,
        });
      }

      return record!;
    });

    return c.json(UpdatePublicRecordResponse.parse(row));
  } catch (e) {
    const field = parseUniqueConflictField(e, uniqueFields);
    if (field) return c.json({ error: `Duplicate value for unique field: ${field}` }, 409);
    throw e;
  }
});

// DELETE — only owner can delete their own record (if _ownerId set).
// record_unique_values rows are removed automatically via ON DELETE CASCADE.
publicDataRouter.delete("/v1/data/:collection/:recordId", async (c) => {
  const existing = await loadScopedRecord(c);
  if (!existing) return c.json({ error: "Record not found" }, 404);

  const ownerId = (existing.data as Record<string, unknown>)._ownerId;
  if (ownerId !== undefined) {
    const token = bearerToken(c);
    if (!token) return c.json({ error: "Authorization token required to delete this record" }, 401);
    const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
    if (!payload || String(payload.endUserId) !== String(ownerId)) return c.json({ error: "You do not own this record" }, 403);
  }

  const db = getDb(c);
  await db.delete(recordsTable).where(eq(recordsTable.id, existing.id));
  return c.body(null, 204);
});

// POST /v1/data/:collection/:recordId/increment — atomically bump a numeric field.
publicDataRouter.post("/v1/data/:collection/:recordId/increment", async (c) => {
  const existing = await loadScopedRecord(c);
  if (!existing) return c.json({ error: "Record not found" }, 404);

  const parsed = IncrementPublicRecordFieldBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);
  if (!FIELD_NAME_RE.test(parsed.data.field)) return c.json({ error: "Invalid field name" }, 400);

  const { field, amount = 1 } = parsed.data;
  const path = "$." + field;

  const db = getDb(c);
  const [row] = await db
    .update(recordsTable)
    .set({
      data: sql`json_set(${recordsTable.data}, ${path}, COALESCE(json_extract(${recordsTable.data}, ${path}), 0) + ${amount})`,
      updatedAt: new Date(),
    })
    .where(eq(recordsTable.id, existing.id))
    .returning();

  return c.json(IncrementPublicRecordFieldResponse.parse(row));
});
