import { Hono } from "hono";
import { healthRouter } from "./health";
import { projectsRouter } from "./projects";
import { apiKeysRouter } from "./apiKeys";
import { endUsersRouter } from "./endUsers";
import { recordsRouter } from "./records";
import { filesRouter } from "./files";
import { objectStorageRouter } from "./objectStorage";
import { publicAuthRouter } from "./publicAuth";
import { publicDataRouter } from "./publicData";
import { publicStorageRouter } from "./publicStorage";
import { publicCollectionsRouter, dashboardCollectionsRouter } from "./collections";
import type { AppEnv } from "../types";

export const apiRouter = new Hono<AppEnv>();

apiRouter.route("/", healthRouter);
apiRouter.route("/", projectsRouter);
apiRouter.route("/", apiKeysRouter);
apiRouter.route("/", endUsersRouter);
apiRouter.route("/", recordsRouter);
apiRouter.route("/", filesRouter);
apiRouter.route("/", dashboardCollectionsRouter); // dashboard: requireAuth
apiRouter.route("/", objectStorageRouter);
apiRouter.route("/", publicAuthRouter);
apiRouter.route("/", publicDataRouter);
apiRouter.route("/", publicStorageRouter);
apiRouter.route("/", publicCollectionsRouter);   // public v1: apiKeyAuth
