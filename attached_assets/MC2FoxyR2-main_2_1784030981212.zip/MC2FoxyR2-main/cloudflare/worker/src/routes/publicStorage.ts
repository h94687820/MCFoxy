import { Hono } from "hono";
import { eq, and } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { RequestPublicUploadUrlBody, ListPublicFilesResponse } from "@workspace/api-zod";
import { filesTable } from "../schema";
import { apiKeyAuth } from "../middlewares/apiKeyAuth";
import { verifyEndUserToken } from "../lib/endUserToken";
import { getDb, getProjectId, parseId, bearerToken } from "../lib/context";
import { MAX_UPLOAD_SIZE_BYTES } from "../lib/storage";
import { signUploadToken } from "../lib/crypto";
import type { AppEnv } from "../types";

export const publicStorageRouter = new Hono<AppEnv>();
publicStorageRouter.use(apiKeyAuth);

const PublicUploadBody = z
  .object({
    name: z.string().min(1),
    size: z.number().int().nonnegative().max(MAX_UPLOAD_SIZE_BYTES, "File exceeds maximum size of 100MB"),
    contentType: z.string().default("application/octet-stream"),
    uploadedBy: z.string().optional(),
  })
  .refine((body) => RequestPublicUploadUrlBody.safeParse(body).success);

// POST /v1/storage/upload — get an upload URL (see routes/objectStorage.ts for the actual PUT handler)
publicStorageRouter.post("/v1/storage/upload", async (c) => {
  if (!c.env.BUCKET) return c.json({ error: "File storage is not configured on this deployment" }, 501);
  const parsed = PublicUploadBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const { name, size, contentType, uploadedBy } = parsed.data;
  const projectId = getProjectId(c);

  let resolvedUploadedBy = uploadedBy;
  const token = bearerToken(c);
  if (token && !resolvedUploadedBy) {
    const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
    if (payload && payload.projectId === projectId) resolvedUploadedBy = String(payload.endUserId);
  }

  const key = randomUUID();
  const objectPath = `/objects/${key}`;
  const db = getDb(c);
  const [file] = await db
    .insert(filesTable)
    .values({ projectId, name, objectPath, contentType, size, uploadedBy: resolvedUploadedBy ?? null })
    .returning();

  const uploadToken = signUploadToken(key, c.env.SESSION_SECRET);
  const uploadURL = `/api/storage${objectPath}?uploadToken=${uploadToken}`;
  const origin = new URL(c.req.url).origin;
  return c.json({ uploadURL, objectPath, downloadUrl: `${origin}/api/storage${objectPath}`, fileId: file.id });
});

// GET /v1/storage — list files for this project. ?uploadedBy=me requires Authorization token
publicStorageRouter.get("/v1/storage", async (c) => {
  const projectId = getProjectId(c);
  const conditions = [eq(filesTable.projectId, projectId)];

  const uploadedByQuery = c.req.query("uploadedBy");
  if (uploadedByQuery === "me") {
    const token = bearerToken(c);
    if (!token) return c.json({ error: "Authorization token required for uploadedBy=me" }, 401);
    const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
    if (!payload || payload.projectId !== projectId) return c.json({ error: "Invalid token" }, 401);
    conditions.push(eq(filesTable.uploadedBy, String(payload.endUserId)));
  } else if (uploadedByQuery) {
    conditions.push(eq(filesTable.uploadedBy, uploadedByQuery));
  }

  const db = getDb(c);
  const rows = await db.select().from(filesTable).where(and(...conditions)).orderBy(filesTable.createdAt);

  const origin = new URL(c.req.url).origin;
  const withUrls = rows.map((f) => ({ ...f, downloadUrl: `${origin}/api/storage${f.objectPath}` }));
  return c.json(ListPublicFilesResponse.parse(rows).map((f, i) => ({ ...f, downloadUrl: withUrls[i]!.downloadUrl })));
});

// GET /v1/storage/:fileId — get single file info + download URL
publicStorageRouter.get("/v1/storage/:fileId", async (c) => {
  const fileId = parseId(c.req.param("fileId"));
  if (Number.isNaN(fileId)) return c.json({ error: "Invalid file ID" }, 400);

  const db = getDb(c);
  const [file] = await db
    .select()
    .from(filesTable)
    .where(and(eq(filesTable.id, fileId), eq(filesTable.projectId, getProjectId(c))))
    .limit(1);
  if (!file) return c.json({ error: "File not found" }, 404);

  const origin = new URL(c.req.url).origin;
  return c.json({ ...file, downloadUrl: `${origin}/api/storage${file.objectPath}` });
});

// DELETE /v1/storage/:fileId — delete a file (owner only if uploadedBy set)
publicStorageRouter.delete("/v1/storage/:fileId", async (c) => {
  if (!c.env.BUCKET) return c.json({ error: "File storage is not configured on this deployment" }, 501);
  const fileId = parseId(c.req.param("fileId"));
  if (Number.isNaN(fileId)) return c.json({ error: "Invalid file ID" }, 400);

  const projectId = getProjectId(c);
  const db = getDb(c);
  const [file] = await db
    .select()
    .from(filesTable)
    .where(and(eq(filesTable.id, fileId), eq(filesTable.projectId, projectId)))
    .limit(1);
  if (!file) return c.json({ error: "File not found" }, 404);

  if (file.uploadedBy) {
    const token = bearerToken(c);
    if (!token) return c.json({ error: "Authorization token required to delete this file" }, 401);
    const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
    if (!payload || String(payload.endUserId) !== file.uploadedBy) return c.json({ error: "You do not own this file" }, 403);
  }

  await db.delete(filesTable).where(eq(filesTable.id, fileId));
  if (c.env.BUCKET) await c.env.BUCKET.delete(`uploads/${file.objectPath.replace(/^\/objects\//, "")}`);
  return c.body(null, 204);
});
