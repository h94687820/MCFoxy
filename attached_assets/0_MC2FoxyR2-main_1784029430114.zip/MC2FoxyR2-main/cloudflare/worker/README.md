# BaaS Platform — Cloudflare Worker

Standalone Cloudflare deployment of the BaaS platform: a single Worker serves
the dashboard's static frontend **and** the public/dashboard API, backed by
D1 (Postgres replacement) and R2 (object storage replacement). It is a
self-contained port of `artifacts/api-server` + `artifacts/dashboard` — no
other folder or project is needed to deploy it.

## Architecture

- `src/index.ts` — Hono app. `/api/*` hits the Worker; everything else is
  served as static files from `./public` (built from `artifacts/dashboard`),
  with SPA fallback so client-side routes resolve correctly.
- D1 binding `DB` — mirrors the Postgres schema (`migrations/0001_init.sql`).
- R2 binding `BUCKET` — replaces the GCS-based object storage used on Replit.
- Auth: a **separate, self-managed Clerk application** — not the
  Replit-managed one used by the Replit-hosted dashboard preview. Replit's
  Clerk tenant only works on Replit domains (it relies on Replit's
  host-based key resolution and a `/api/__clerk` proxy); it cannot
  authenticate a site served from a Cloudflare Worker domain. This is why
  you need your own Clerk keys, configured below.

## One-time setup

### 1. Cloudflare

```bash
pnpm exec wrangler login
pnpm exec wrangler d1 create baas-platform-db
```

Copy the returned `database_id` into `wrangler.toml` under `[[d1_databases]]`
(replace `REPLACE_WITH_YOUR_D1_DATABASE_ID`).

```bash
pnpm exec wrangler r2 bucket create baas-platform-files
```

### 2. Clerk (auth)

1. Create a free account at [clerk.com](https://clerk.com) and create a new
   application (this is separate from any Replit-managed Clerk app).
2. From **API Keys**, copy the **Publishable key** and **Secret key**.
3. Set them as Replit secrets in this project: `CF_CLERK_PUBLISHABLE_KEY` and
   `CF_CLERK_SECRET_KEY`. (These are distinct from `VITE_CLERK_PUBLISHABLE_KEY`
   / `CLERK_SECRET_KEY`, which belong to the Replit-managed Clerk tenant used
   by the Replit-hosted dashboard — don't reuse those here.)
4. `wrangler.toml`'s `[vars] CLERK_PUBLISHABLE_KEY` is already filled in from
   `CF_CLERK_PUBLISHABLE_KEY` (publishable keys are not secret, so they live
   directly in config). If you rotate the key, update it there too.

### 3. Push secrets to Cloudflare

```bash
pnpm run secrets:push
```

Sets `CLERK_SECRET_KEY` (from `CF_CLERK_SECRET_KEY`) and `SESSION_SECRET`
(auto-generated HMAC key for end-user bearer tokens) as Worker secrets.

### 4. Run database migrations

```bash
pnpm run db:migrate:remote
```

(Use `db:migrate:local` for local `wrangler dev` testing.)

## Deploy

```bash
pnpm run deploy
```

This builds the dashboard frontend into `./public` (baking in
`CF_CLERK_PUBLISHABLE_KEY`, not the Replit-managed key) and runs
`wrangler deploy`.

## Local dev against Cloudflare bindings

```bash
pnpm run db:migrate:local
pnpm run build:frontend
pnpm run dev
```

## Notes

- If you rotate Clerk keys, re-run `pnpm run secrets:push` and redeploy so
  the new publishable key is baked into the frontend build too.
- `SESSION_SECRET` only needs to be internally consistent on Cloudflare — it
  does not need to match the Replit project's `SESSION_SECRET`.
