#!/usr/bin/env node
// One-time (or whenever keys rotate) setup: pushes the worker's runtime
// secrets to Cloudflare via `wrangler secret put`. Requires `wrangler login`
// (or CLOUDFLARE_API_TOKEN) to already be configured.
//
// - CLERK_SECRET_KEY: from your own standalone Clerk app (CF_CLERK_SECRET_KEY).
// - SESSION_SECRET: HMAC secret for signing end-user bearer tokens. Generated
//   automatically if not already provided via CF_SESSION_SECRET — it does not
//   need to match the Replit project's SESSION_SECRET.
import { spawnSync } from "node:child_process";
import { randomBytes } from "node:crypto";

function pushSecret(name, value) {
  console.log(`Setting ${name}...`);
  const result = spawnSync("pnpm", ["exec", "wrangler", "secret", "put", name], {
    input: value,
    stdio: ["pipe", "inherit", "inherit"],
  });
  if (result.status !== 0) {
    console.error(`Failed to set ${name}`);
    process.exit(result.status ?? 1);
  }
}

const clerkSecretKey = process.env.CF_CLERK_SECRET_KEY;
if (!clerkSecretKey) {
  console.error(
    "Missing CF_CLERK_SECRET_KEY. Copy the Secret key from your Clerk app " +
      "dashboard and set it as the CF_CLERK_SECRET_KEY secret (see README.md).",
  );
  process.exit(1);
}

const sessionSecret = process.env.CF_SESSION_SECRET || randomBytes(32).toString("hex");

pushSecret("CLERK_SECRET_KEY", clerkSecretKey);
pushSecret("SESSION_SECRET", sessionSecret);

console.log("Done. Both secrets are now set on the Cloudflare Worker.");
