#!/usr/bin/env node
// Builds the dashboard frontend (artifacts/dashboard) into ./public so wrangler
// can serve it as static assets alongside the Worker's /api/* routes.
//
// Clerk auth on Cloudflare is a separate, self-managed Clerk application (not
// the Replit-managed one used by the Replit-hosted preview). The publishable
// key below MUST come from CF_CLERK_PUBLISHABLE_KEY, not VITE_CLERK_PUBLISHABLE_KEY
// (that one belongs to Replit's managed Clerk tenant and only works on Replit
// domains). See README.md for how to obtain CF_CLERK_PUBLISHABLE_KEY.
import { spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const workerDir = path.resolve(here, "..");
const dashboardDir = path.resolve(workerDir, "../../artifacts/dashboard");

const publishableKey = process.env.CF_CLERK_PUBLISHABLE_KEY;
if (!publishableKey) {
  console.error(
    "Missing CF_CLERK_PUBLISHABLE_KEY. Create your own Clerk app at " +
      "https://clerk.com, copy its Publishable key, and set it as the " +
      "CF_CLERK_PUBLISHABLE_KEY secret (see README.md).",
  );
  process.exit(1);
}

const result = spawnSync(
  "pnpm",
  [
    "exec",
    "vite",
    "build",
    "--config",
    "vite.config.ts",
    "--outDir",
    path.join(workerDir, "public"),
    "--base",
    "/",
  ],
  {
    cwd: dashboardDir,
    stdio: "inherit",
    env: {
      ...process.env,
      BASE_PATH: "/",
      PORT: "1",
      // Override the Replit-managed key with the standalone Cloudflare Clerk key.
      VITE_CLERK_PUBLISHABLE_KEY: publishableKey,
      // Intentionally NOT set: VITE_CLERK_PROXY_URL. The Replit proxy only
      // works on Replit-hosted domains; a self-managed Clerk app talks to
      // Clerk's Frontend API directly, which is the correct behavior here.
      VITE_CLERK_PROXY_URL: "",
    },
  },
);

process.exit(result.status ?? 1);
