import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Lightweight signed bearer token for end users of a project's public v1 API.
 * Same format as artifacts/api-server/src/lib/endUserToken.ts, except the
 * signing secret is passed explicitly (Workers don't have `process.env`
 * populated with bindings — secrets come from `c.env.SESSION_SECRET` per request).
 */

interface EndUserTokenPayload {
  endUserId: number;
  projectId: number;
  iat: number;
}

function sign(data: string, secret: string): string {
  return createHmac("sha256", secret).update(data).digest("base64url");
}

export function signEndUserToken(
  payload: { endUserId: number; projectId: number },
  secret: string,
): string {
  const body: EndUserTokenPayload = { ...payload, iat: Date.now() };
  const encodedBody = Buffer.from(JSON.stringify(body)).toString("base64url");
  const signature = sign(encodedBody, secret);
  return `${encodedBody}.${signature}`;
}

export function verifyEndUserToken(token: string, secret: string): EndUserTokenPayload | null {
  const [encodedBody, signature] = token.split(".");
  if (!encodedBody || !signature) return null;

  const expectedSignature = sign(encodedBody, secret);
  const sigBuf = Buffer.from(signature);
  const expectedBuf = Buffer.from(expectedSignature);
  if (sigBuf.length !== expectedBuf.length || !timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }

  try {
    const body = JSON.parse(Buffer.from(encodedBody, "base64url").toString("utf8")) as EndUserTokenPayload;
    if (typeof body.endUserId !== "number" || typeof body.projectId !== "number") {
      return null;
    }
    return body;
  } catch {
    return null;
  }
}
