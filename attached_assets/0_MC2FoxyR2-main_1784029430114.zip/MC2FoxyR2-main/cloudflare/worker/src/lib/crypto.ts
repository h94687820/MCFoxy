import { randomBytes, createHash, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

// Identical logic to artifacts/api-server/src/lib/crypto.ts — ported as-is
// because Cloudflare Workers' `nodejs_compat` flag supports node:crypto,
// including scrypt/timingSafeEqual, so no Web Crypto rewrite is needed.

const scryptAsync = promisify(scrypt);

export function hashApiKeySecret(secret: string): string {
  return createHash("sha256").update(secret).digest("hex");
}

export function generateApiKey(): { keyPrefix: string; secret: string } {
  const raw = randomBytes(24).toString("base64url");
  const secret = `bk_live_${raw}`;
  const keyPrefix = secret.slice(0, 14);
  return { keyPrefix, secret };
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [salt, hashHex] = stored.split(":");
  if (!salt || !hashHex) return false;
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  const storedBuf = Buffer.from(hashHex, "hex");
  if (derived.length !== storedBuf.length) return false;
  return timingSafeEqual(derived, storedBuf);
}
