import { drizzle } from "drizzle-orm/d1";
import { eq, and } from "drizzle-orm";
import type { Context } from "hono";
import { projectsTable } from "../schema";
import type { AppEnv } from "../types";

export function getDb(c: Context<AppEnv>) {
  return drizzle(c.env.DB);
}

export function parseId(raw: string | undefined): number {
  return parseInt(raw ?? "", 10);
}

export function getUserId(c: Context<AppEnv>): string {
  const userId = c.get("userId");
  if (!userId) throw new Error("userId not set — requireAuth middleware missing");
  return userId;
}

export function getProjectId(c: Context<AppEnv>): number {
  const projectId = c.get("projectId");
  if (projectId === undefined) throw new Error("projectId not set — apiKeyAuth middleware missing");
  return projectId;
}

export function getEndUserId(c: Context<AppEnv>): number | undefined {
  return c.get("endUserId");
}

export function bearerToken(c: Context<AppEnv>): string | undefined {
  const header = c.req.header("Authorization");
  return header?.startsWith("Bearer ") ? header.slice(7) : undefined;
}

/** Loads a project owned by the signed-in dashboard user, scoped by :projectId. */
export async function loadOwnedProject(c: Context<AppEnv>) {
  const db = getDb(c);
  const projectId = parseId(c.req.param("projectId"));
  const userId = getUserId(c);
  const [row] = await db
    .select()
    .from(projectsTable)
    .where(and(eq(projectsTable.id, projectId), eq(projectsTable.ownerId, userId)))
    .limit(1);
  return row;
}
