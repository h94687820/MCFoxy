/** Maximum accepted upload size for any file (100 MB) — same limit as the
 * Replit-hosted version, enforced both on the metadata POST (declared size)
 * and on the actual PUT body (Content-Length header) for defense in depth. */
export const MAX_UPLOAD_SIZE_BYTES = 100 * 1024 * 1024;
