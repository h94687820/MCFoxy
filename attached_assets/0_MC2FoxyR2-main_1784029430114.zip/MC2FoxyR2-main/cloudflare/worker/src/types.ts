export interface CloudflareBindings {
  DB: D1Database;
  // Optional: R2 is not enabled on this Cloudflare account yet. File-storage
  // routes check for this and return 501 when it's undefined.
  BUCKET?: R2Bucket;
  ASSETS: Fetcher;
  CLERK_SECRET_KEY: string;
  CLERK_PUBLISHABLE_KEY: string;
  SESSION_SECRET: string;
}

export interface AppVariables {
  userId?: string;
  projectId?: number;
  endUserId?: number;
}

export type AppEnv = { Bindings: CloudflareBindings; Variables: AppVariables };
