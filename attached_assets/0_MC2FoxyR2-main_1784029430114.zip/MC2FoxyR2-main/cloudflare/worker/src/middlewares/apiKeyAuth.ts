import { eq } from "drizzle-orm";
import type { MiddlewareHandler } from "hono";
import { apiKeysTable } from "../schema";
import { hashApiKeySecret } from "../lib/crypto";
import { getDb } from "../lib/context";
import type { AppEnv } from "../types";

/** Protects public v1 API routes: requires a valid `X-API-Key` header and
 * attaches the resolved `projectId` context variable for the calling project. */
export const apiKeyAuth: MiddlewareHandler<AppEnv> = async (c, next) => {
  const header = c.req.header("X-API-Key");
  if (!header) {
    return c.json({ error: "Missing X-API-Key header" }, 401);
  }

  const db = getDb(c);
  const hashedSecret = hashApiKeySecret(header);
  const [key] = await db.select().from(apiKeysTable).where(eq(apiKeysTable.hashedSecret, hashedSecret)).limit(1);

  if (!key) {
    return c.json({ error: "Invalid API key" }, 401);
  }

  await db.update(apiKeysTable).set({ lastUsedAt: new Date() }).where(eq(apiKeysTable.id, key.id));

  c.set("projectId", key.projectId);
  return next();
};
