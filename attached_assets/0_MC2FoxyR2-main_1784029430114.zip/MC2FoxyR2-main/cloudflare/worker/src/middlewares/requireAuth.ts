import { createClerkClient } from "@clerk/backend";
import type { MiddlewareHandler } from "hono";
import type { AppEnv } from "../types";

/** Protects dashboard routes: requires a signed-in Clerk session and
 * attaches the Clerk user id as the `userId` context variable.
 *
 * Port of artifacts/api-server/src/middlewares/requireAuth.ts's `@clerk/express`
 * middleware to `@clerk/backend`'s fetch-based `authenticateRequest`, which
 * runs directly on the standard Request object available in Workers. */
export const requireAuth: MiddlewareHandler<AppEnv> = async (c, next) => {
  const clerkClient = createClerkClient({
    secretKey: c.env.CLERK_SECRET_KEY,
    publishableKey: c.env.CLERK_PUBLISHABLE_KEY,
  });

  const requestState = await clerkClient.authenticateRequest(c.req.raw, {
    authorizedParties: [new URL(c.req.url).origin],
  });

  const userId = requestState.toAuth()?.userId;
  if (!userId) {
    return c.json({ error: "Unauthorized" }, 401);
  }

  c.set("userId", userId);
  return next();
};
