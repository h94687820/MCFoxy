import type { MiddlewareHandler } from "hono";
import { verifyEndUserToken } from "../lib/endUserToken";
import { bearerToken } from "../lib/context";
import type { AppEnv } from "../types";

/** Protects public v1 API routes that act on behalf of a specific end user
 * (e.g. GET /v1/auth/me). Must run after `apiKeyAuth` so `projectId` is
 * already set; verifies the bearer token belongs to that same project. */
export const endUserAuth: MiddlewareHandler<AppEnv> = async (c, next) => {
  const token = bearerToken(c);
  if (!token) {
    return c.json({ error: "Missing Authorization bearer token" }, 401);
  }

  const payload = verifyEndUserToken(token, c.env.SESSION_SECRET);
  const projectId = c.get("projectId");
  if (!payload || payload.projectId !== projectId) {
    return c.json({ error: "Invalid or expired token" }, 401);
  }

  c.set("endUserId", payload.endUserId);
  return next();
};
