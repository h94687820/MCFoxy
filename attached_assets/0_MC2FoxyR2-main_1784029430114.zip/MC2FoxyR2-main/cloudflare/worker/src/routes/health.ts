import { Hono } from "hono";
import { HealthCheckResponse } from "@workspace/api-zod";
import type { AppEnv } from "../types";

export const healthRouter = new Hono<AppEnv>();

healthRouter.get("/healthz", (c) => c.json(HealthCheckResponse.parse({ status: "ok" })));
