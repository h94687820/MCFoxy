import { Hono } from "hono";
import { eq, and } from "drizzle-orm";
import { ListApiKeysResponse, CreateApiKeyBody, CreateApiKeyResponse } from "@workspace/api-zod";
import { apiKeysTable } from "../schema";
import { requireAuth } from "../middlewares/requireAuth";
import { getDb, loadOwnedProject, parseId } from "../lib/context";
import { generateApiKey, hashApiKeySecret } from "../lib/crypto";
import type { AppEnv } from "../types";

export const apiKeysRouter = new Hono<AppEnv>();
apiKeysRouter.use(requireAuth);

apiKeysRouter.get("/projects/:projectId/apiKeys", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const db = getDb(c);
  const rows = await db.select().from(apiKeysTable).where(eq(apiKeysTable.projectId, project.id));
  return c.json(ListApiKeysResponse.parse(rows));
});

apiKeysRouter.post("/projects/:projectId/apiKeys", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const parsed = CreateApiKeyBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const { keyPrefix, secret } = generateApiKey();
  const db = getDb(c);
  const [row] = await db
    .insert(apiKeysTable)
    .values({
      projectId: project.id,
      name: parsed.data.name,
      keyPrefix,
      hashedSecret: hashApiKeySecret(secret),
    })
    .returning();

  return c.json(CreateApiKeyResponse.parse({ ...row, secret }), 201);
});

apiKeysRouter.delete("/projects/:projectId/apiKeys/:keyId", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const keyId = parseId(c.req.param("keyId"));
  const db = getDb(c);
  await db.delete(apiKeysTable).where(and(eq(apiKeysTable.id, keyId), eq(apiKeysTable.projectId, project.id)));
  return c.body(null, 204);
});
