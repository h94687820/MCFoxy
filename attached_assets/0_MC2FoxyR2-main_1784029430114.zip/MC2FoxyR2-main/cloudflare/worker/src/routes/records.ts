import { Hono } from "hono";
import { eq, and } from "drizzle-orm";
import { ListDataRecordsResponse } from "@workspace/api-zod";
import { recordsTable } from "../schema";
import { requireAuth } from "../middlewares/requireAuth";
import { getDb, loadOwnedProject, parseId } from "../lib/context";
import type { AppEnv } from "../types";

export const recordsRouter = new Hono<AppEnv>();
recordsRouter.use(requireAuth);

recordsRouter.get("/projects/:projectId/records", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const db = getDb(c);
  const rows = await db.select().from(recordsTable).where(eq(recordsTable.projectId, project.id));
  return c.json(ListDataRecordsResponse.parse(rows));
});

recordsRouter.delete("/projects/:projectId/records/:recordId", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const recordId = parseId(c.req.param("recordId"));
  const db = getDb(c);
  await db.delete(recordsTable).where(and(eq(recordsTable.id, recordId), eq(recordsTable.projectId, project.id)));
  return c.body(null, 204);
});
