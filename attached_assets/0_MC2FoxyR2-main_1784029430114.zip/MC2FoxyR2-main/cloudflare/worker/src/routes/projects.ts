import { Hono } from "hono";
import { eq, count } from "drizzle-orm";
import {
  ListProjectsResponse,
  CreateProjectBody,
  CreateProjectResponse,
  GetProjectResponse,
  UpdateProjectBody,
  UpdateProjectResponse,
  GetProjectStatsResponse,
} from "@workspace/api-zod";
import { projectsTable, apiKeysTable, endUsersTable, recordsTable } from "../schema";
import { requireAuth } from "../middlewares/requireAuth";
import { getDb, getUserId, loadOwnedProject } from "../lib/context";
import type { AppEnv } from "../types";

export const projectsRouter = new Hono<AppEnv>();
projectsRouter.use(requireAuth);

projectsRouter.get("/projects", async (c) => {
  const db = getDb(c);
  const rows = await db.select().from(projectsTable).where(eq(projectsTable.ownerId, getUserId(c)));
  const data = rows.map((row) => ({ ...row, updatedAt: row.createdAt }));
  return c.json(ListProjectsResponse.parse(data));
});

projectsRouter.post("/projects", async (c) => {
  const parsed = CreateProjectBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const db = getDb(c);
  const [row] = await db
    .insert(projectsTable)
    .values({ ...parsed.data, ownerId: getUserId(c) })
    .returning();

  return c.json(CreateProjectResponse.parse({ ...row, updatedAt: row.createdAt }), 201);
});

projectsRouter.get("/projects/:projectId", async (c) => {
  const row = await loadOwnedProject(c);
  if (!row) return c.json({ error: "Project not found" }, 404);
  return c.json(GetProjectResponse.parse({ ...row, updatedAt: row.createdAt }));
});

projectsRouter.patch("/projects/:projectId", async (c) => {
  const existing = await loadOwnedProject(c);
  if (!existing) return c.json({ error: "Project not found" }, 404);

  const parsed = UpdateProjectBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const db = getDb(c);
  const [row] = await db.update(projectsTable).set(parsed.data).where(eq(projectsTable.id, existing.id)).returning();
  return c.json(UpdateProjectResponse.parse({ ...row, updatedAt: row.createdAt }));
});

projectsRouter.delete("/projects/:projectId", async (c) => {
  const existing = await loadOwnedProject(c);
  if (!existing) return c.json({ error: "Project not found" }, 404);

  const db = getDb(c);
  await db.delete(projectsTable).where(eq(projectsTable.id, existing.id));
  return c.body(null, 204);
});

projectsRouter.get("/projects/:projectId/stats", async (c) => {
  const existing = await loadOwnedProject(c);
  if (!existing) return c.json({ error: "Project not found" }, 404);

  const db = getDb(c);
  const [[endUserCount], [apiKeyCount], recordRows] = await Promise.all([
    db.select({ value: count() }).from(endUsersTable).where(eq(endUsersTable.projectId, existing.id)),
    db.select({ value: count() }).from(apiKeysTable).where(eq(apiKeysTable.projectId, existing.id)),
    db.select({ collection: recordsTable.collection }).from(recordsTable).where(eq(recordsTable.projectId, existing.id)),
  ]);

  const collectionCount = new Set(recordRows.map((r) => r.collection)).size;

  return c.json(
    GetProjectStatsResponse.parse({
      projectId: existing.id,
      endUserCount: endUserCount?.value ?? 0,
      recordCount: recordRows.length,
      collectionCount,
      apiKeyCount: apiKeyCount?.value ?? 0,
    }),
  );
});
