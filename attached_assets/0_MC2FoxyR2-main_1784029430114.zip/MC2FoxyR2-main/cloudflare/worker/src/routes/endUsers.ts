import { Hono } from "hono";
import { eq, and } from "drizzle-orm";
import { ListEndUsersResponse } from "@workspace/api-zod";
import { endUsersTable } from "../schema";
import { requireAuth } from "../middlewares/requireAuth";
import { getDb, loadOwnedProject, parseId } from "../lib/context";
import type { AppEnv } from "../types";

export const endUsersRouter = new Hono<AppEnv>();
endUsersRouter.use(requireAuth);

endUsersRouter.get("/projects/:projectId/endUsers", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const db = getDb(c);
  const rows = await db.select().from(endUsersTable).where(eq(endUsersTable.projectId, project.id));
  return c.json(ListEndUsersResponse.parse(rows));
});

endUsersRouter.delete("/projects/:projectId/endUsers/:endUserId", async (c) => {
  const project = await loadOwnedProject(c);
  if (!project) return c.json({ error: "Project not found" }, 404);

  const endUserId = parseId(c.req.param("endUserId"));
  const db = getDb(c);
  await db.delete(endUsersTable).where(and(eq(endUsersTable.id, endUserId), eq(endUsersTable.projectId, project.id)));
  return c.body(null, 204);
});
