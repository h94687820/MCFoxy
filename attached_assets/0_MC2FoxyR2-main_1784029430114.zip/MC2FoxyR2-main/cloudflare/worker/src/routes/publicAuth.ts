import { Hono } from "hono";
import { eq, and } from "drizzle-orm";
import {
  RegisterEndUserBody,
  RegisterEndUserResponse,
  LoginEndUserBody,
  LoginEndUserResponse,
  GetCurrentEndUserResponse,
} from "@workspace/api-zod";
import { endUsersTable } from "../schema";
import { apiKeyAuth } from "../middlewares/apiKeyAuth";
import { endUserAuth } from "../middlewares/endUserAuth";
import { hashPassword, verifyPassword } from "../lib/crypto";
import { signEndUserToken } from "../lib/endUserToken";
import { getDb, getProjectId, getEndUserId } from "../lib/context";
import type { AppEnv } from "../types";

export const publicAuthRouter = new Hono<AppEnv>();

publicAuthRouter.post("/v1/auth/register", apiKeyAuth, async (c) => {
  const parsed = RegisterEndUserBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const projectId = getProjectId(c);
  const db = getDb(c);
  const [existing] = await db
    .select()
    .from(endUsersTable)
    .where(and(eq(endUsersTable.projectId, projectId), eq(endUsersTable.email, parsed.data.email)))
    .limit(1);

  if (existing) return c.json({ error: "Email already registered" }, 409);

  const passwordHash = await hashPassword(parsed.data.password);
  const [endUser] = await db
    .insert(endUsersTable)
    .values({ projectId, email: parsed.data.email, passwordHash, name: parsed.data.name })
    .returning();

  const token = signEndUserToken({ endUserId: endUser.id, projectId }, c.env.SESSION_SECRET);
  return c.json(RegisterEndUserResponse.parse({ token, endUser }), 201);
});

publicAuthRouter.post("/v1/auth/login", apiKeyAuth, async (c) => {
  const parsed = LoginEndUserBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const projectId = getProjectId(c);
  const db = getDb(c);
  const [endUser] = await db
    .select()
    .from(endUsersTable)
    .where(and(eq(endUsersTable.projectId, projectId), eq(endUsersTable.email, parsed.data.email)))
    .limit(1);

  const valid = endUser && (await verifyPassword(parsed.data.password, endUser.passwordHash));
  if (!endUser || !valid) return c.json({ error: "Invalid email or password" }, 401);

  const token = signEndUserToken({ endUserId: endUser.id, projectId }, c.env.SESSION_SECRET);
  return c.json(LoginEndUserResponse.parse({ token, endUser }));
});

publicAuthRouter.get("/v1/auth/me", apiKeyAuth, endUserAuth, async (c) => {
  const endUserId = getEndUserId(c)!;
  const db = getDb(c);
  const [endUser] = await db.select().from(endUsersTable).where(eq(endUsersTable.id, endUserId)).limit(1);
  if (!endUser) return c.json({ error: "End user not found" }, 404);
  return c.json(GetCurrentEndUserResponse.parse(endUser));
});
