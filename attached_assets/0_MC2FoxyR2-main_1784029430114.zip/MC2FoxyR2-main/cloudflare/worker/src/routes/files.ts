import { Hono } from "hono";
import { eq, and } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { RequestUploadUrlResponse, ListProjectFilesResponse } from "@workspace/api-zod";
import { filesTable } from "../schema";
import { requireAuth } from "../middlewares/requireAuth";
import { getDb, parseId } from "../lib/context";
import { MAX_UPLOAD_SIZE_BYTES } from "../lib/storage";
import type { AppEnv } from "../types";

export const filesRouter = new Hono<AppEnv>();
filesRouter.use(requireAuth);

const UploadUrlBody = z.object({
  name: z.string().min(1),
  size: z.number().int().nonnegative().max(MAX_UPLOAD_SIZE_BYTES, "File exceeds maximum size of 100MB"),
  contentType: z.string().default("application/octet-stream"),
});

filesRouter.post("/projects/:projectId/files/request-upload-url", async (c) => {
  if (!c.env.BUCKET) return c.json({ error: "File storage is not configured on this deployment" }, 501);
  const projectId = parseId(c.req.param("projectId"));
  const parsed = UploadUrlBody.safeParse(await c.req.json().catch(() => null));
  if (!parsed.success) return c.json({ error: parsed.error.message }, 400);

  const { name, size, contentType } = parsed.data;
  const objectPath = `/objects/${randomUUID()}`;

  const db = getDb(c);
  await db.insert(filesTable).values({ projectId, name, objectPath, contentType, size });

  return c.json(RequestUploadUrlResponse.parse({ uploadURL: `/api/storage${objectPath}`, objectPath }));
});

filesRouter.get("/projects/:projectId/files", async (c) => {
  const projectId = parseId(c.req.param("projectId"));
  const db = getDb(c);
  const rows = await db.select().from(filesTable).where(eq(filesTable.projectId, projectId)).orderBy(filesTable.createdAt);
  return c.json(ListProjectFilesResponse.parse(rows));
});

filesRouter.delete("/projects/:projectId/files/:fileId", async (c) => {
  if (!c.env.BUCKET) return c.json({ error: "File storage is not configured on this deployment" }, 501);
  const projectId = parseId(c.req.param("projectId"));
  const fileId = parseId(c.req.param("fileId"));

  const db = getDb(c);
  const [file] = await db
    .select()
    .from(filesTable)
    .where(and(eq(filesTable.id, fileId), eq(filesTable.projectId, projectId)))
    .limit(1);
  if (!file) return c.json({ error: "File not found" }, 404);

  await db.delete(filesTable).where(eq(filesTable.id, fileId));
  if (c.env.BUCKET) await c.env.BUCKET.delete(`uploads/${file.objectPath.replace(/^\/objects\//, "")}`);
  return c.body(null, 204);
});
