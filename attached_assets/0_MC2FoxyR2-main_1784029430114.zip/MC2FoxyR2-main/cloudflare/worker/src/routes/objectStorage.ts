import { Hono } from "hono";
import { MAX_UPLOAD_SIZE_BYTES } from "../lib/storage";
import type { AppEnv } from "../types";

export const objectStorageRouter = new Hono<AppEnv>();

/**
 * PUT/GET /storage/objects/:key
 *
 * Direct-through-worker R2 storage, replacing the Postgres version's
 * GCS-sidecar presigned URLs. The two-step client flow is preserved
 * (request metadata -> PUT the file to the returned uploadURL) but the
 * "presigned URL" is just this same-origin endpoint; the Worker streams
 * the body straight into R2 via `env.BUCKET.put()`.
 *
 * Simplification vs. the Postgres version: there's a single object
 * namespace here (no separate public/private ACL-checked dirs) since none
 * of the current routes exercise that distinction.
 */
objectStorageRouter.put("/storage/objects/:key", async (c) => {
  if (!c.env.BUCKET) return c.json({ error: "File storage is not configured on this deployment" }, 501);
  const key = c.req.param("key");
  const contentLength = c.req.header("content-length");
  if (contentLength && Number(contentLength) > MAX_UPLOAD_SIZE_BYTES) {
    return c.json({ error: "File exceeds maximum size of 100MB" }, 400);
  }

  const contentType = c.req.header("content-type") || "application/octet-stream";
  await c.env.BUCKET.put(`uploads/${key}`, c.req.raw.body, { httpMetadata: { contentType } });
  return c.body(null, 204);
});

objectStorageRouter.get("/storage/objects/:key", async (c) => {
  if (!c.env.BUCKET) return c.json({ error: "File storage is not configured on this deployment" }, 501);
  const object = await c.env.BUCKET.get(`uploads/${c.req.param("key")}`);
  if (!object) return c.json({ error: "Object not found" }, 404);

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);
  headers.set("cache-control", "private, max-age=3600");
  return new Response(object.body, { headers });
});
