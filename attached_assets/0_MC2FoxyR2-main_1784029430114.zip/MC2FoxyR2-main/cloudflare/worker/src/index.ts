import { Hono } from "hono";
import { cors } from "hono/cors";
import { apiRouter } from "./routes";
import type { AppEnv } from "./types";

const app = new Hono<AppEnv>();

// Cross-origin fetches from external sites hitting the public v1 API use
// X-API-Key / bearer tokens, never cookies, so a wide-open origin with no
// credentials is safe here. The dashboard's own Clerk-authenticated calls
// are same-origin (served from this same Worker) and never go through this
// CORS layer at all.
app.use("/api/*", cors({ origin: "*", credentials: false }));

app.route("/api", apiRouter);

// Anything outside /api/* never reaches this script — wrangler.toml's
// `run_worker_first = ["/api/*"]` routes those requests straight to the
// static assets in ./public, with SPA fallback to index.html.

export default app;
