import { Link, useLocation } from "wouter";
import { useClerk, useUser } from "@clerk/react";
import { Database, LayoutDashboard, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const { signOut } = useClerk();
  const { user } = useUser();
  const [location] = useLocation();

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background text-foreground font-sans">
      <aside className="w-full md:w-64 border-b-2 md:border-b-0 md:border-r-2 border-border bg-card flex flex-col shrink-0">
        <div className="p-6 border-b-2 border-border flex items-center gap-3 bg-background/50">
          <Database className="w-6 h-6 text-primary drop-shadow-[2px_2px_0px_rgba(0,0,0,0.1)]" />
          <span className="font-bold text-xl uppercase tracking-widest text-primary">Forge</span>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <Link href="/dashboard" className={cn(
            "flex items-center gap-3 px-4 py-3 font-bold uppercase tracking-wider text-sm transition-all border-2",
            location.startsWith("/dashboard") || location.startsWith("/projects")
              ? "bg-primary text-primary-foreground border-transparent shadow-[4px_4px_0px_0px_rgba(0,0,0,0.15)]" 
              : "border-transparent hover:bg-accent text-muted-foreground hover:text-foreground"
          )}>
            <LayoutDashboard className="w-4 h-4" />
            Projects
          </Link>
        </nav>
        <div className="p-4 border-t-2 border-border flex flex-col gap-4 bg-background/50">
          <div className="flex items-center gap-3 px-2 font-mono text-xs truncate">
            <div className="w-8 h-8 shrink-0 bg-accent border-2 border-border flex items-center justify-center font-bold text-foreground">
              {user?.primaryEmailAddress?.emailAddress.charAt(0).toUpperCase() || "U"}
            </div>
            <span className="truncate text-muted-foreground">{user?.primaryEmailAddress?.emailAddress}</span>
          </div>
          <button 
            onClick={() => signOut({ redirectUrl: "/" })}
            className="flex items-center gap-3 px-4 py-3 font-bold uppercase tracking-wider text-sm transition-colors border-2 border-transparent hover:bg-destructive/10 hover:text-destructive text-muted-foreground text-left w-full"
          >
            <LogOut className="w-4 h-4" />
            Log out
          </button>
        </div>
      </aside>
      <main className="flex-1 flex flex-col h-[100dvh] overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
