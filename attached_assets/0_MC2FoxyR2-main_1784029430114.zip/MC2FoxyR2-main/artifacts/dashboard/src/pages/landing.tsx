import { Link } from "wouter";
import { Database, Zap, Key, Server, TerminalSquare, ShieldAlert } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <header className="border-b-2 border-border p-6 flex justify-between items-center bg-card">
        <div className="flex items-center gap-3">
          <Database className="w-6 h-6 text-primary drop-shadow-[2px_2px_0px_rgba(0,0,0,0.1)]" />
          <span className="font-bold text-xl uppercase tracking-widest text-primary">Forge</span>
        </div>
        <div className="flex gap-4">
          <Link href="/sign-in" className="inline-flex items-center justify-center h-10 px-4 py-2 text-sm font-bold uppercase tracking-wider transition-all border-2 border-transparent hover:border-foreground focus-visible:outline-none">
            Log In
          </Link>
          <Link href="/sign-up" className="inline-flex items-center justify-center h-10 px-6 py-2 text-sm font-bold uppercase tracking-wider transition-all bg-primary text-primary-foreground border-2 border-transparent hover:bg-primary/90 active:translate-y-[2px] shadow-[4px_4px_0px_0px_rgba(0,0,0,0.2)]">
            Deploy Now
          </Link>
        </div>
      </header>
      
      <main className="flex-1 flex flex-col">
        <section className="flex-1 flex flex-col items-center justify-center text-center px-6 py-32 max-w-5xl mx-auto">
          <div className="inline-flex items-center gap-2 border-2 border-primary text-primary px-3 py-1.5 text-xs font-bold uppercase tracking-widest mb-8 bg-primary/5">
            <TerminalSquare className="w-4 h-4" />
            Backend-as-a-Service Platform
          </div>
          <h1 className="text-5xl md:text-8xl font-black uppercase tracking-tighter mb-8 text-balance">
            Your Backend,<br />Zero Servers.
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-3xl font-mono leading-relaxed">
            Spin up a hosted database, user accounts, and an API key instantly. 
            Wire it into your site with a simple REST API. The ultimate cockpit for indie builders who hate devops.
          </p>
          <div className="flex flex-col sm:flex-row gap-6">
            <Link href="/sign-up" className="inline-flex items-center justify-center h-14 px-10 text-lg font-bold uppercase tracking-wider transition-all bg-primary text-primary-foreground hover:bg-primary/90 shadow-[6px_6px_0px_0px_rgba(0,0,0,0.2)] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,0.2)] border-2 border-transparent">
              Start Building
            </Link>
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 p-8 max-w-7xl mx-auto mb-24 border-t-2 border-border pt-16 w-full">
          <div className="border-2 border-border p-8 bg-card shadow-[4px_4px_0px_0px_rgba(0,0,0,0.1)] hover:-translate-y-1 transition-transform">
            <Zap className="w-10 h-10 text-primary mb-6" />
            <h3 className="font-black text-xl uppercase mb-3 tracking-tight">Instant Setup</h3>
            <p className="font-mono text-sm text-muted-foreground leading-relaxed">Get a project running in seconds. We handle the infrastructure, provisioning, and scaling. You handle the frontend.</p>
          </div>
          <div className="border-2 border-border p-8 bg-card shadow-[4px_4px_0px_0px_rgba(0,0,0,0.1)] hover:-translate-y-1 transition-transform">
            <Server className="w-10 h-10 text-primary mb-6" />
            <h3 className="font-black text-xl uppercase mb-3 tracking-tight">Schemaless Store</h3>
            <p className="font-mono text-sm text-muted-foreground leading-relaxed">Store arbitrary JSON documents. Collections are created automatically. Push data directly from your client apps.</p>
          </div>
          <div className="border-2 border-border p-8 bg-card shadow-[4px_4px_0px_0px_rgba(0,0,0,0.1)] hover:-translate-y-1 transition-transform">
            <ShieldAlert className="w-10 h-10 text-primary mb-6" />
            <h3 className="font-black text-xl uppercase mb-3 tracking-tight">Built-in Auth</h3>
            <p className="font-mono text-sm text-muted-foreground leading-relaxed">Secure your requests with project-specific API keys. Rest easy with end-user registration endpoints ready to go.</p>
          </div>
        </section>
      </main>
      <footer className="border-t-2 border-border p-8 text-center font-mono text-sm text-muted-foreground bg-card flex flex-col md:flex-row justify-between items-center max-w-7xl mx-auto w-full">
        <div>SYS.REQ // FORGE CONTROL PANEL v1.0</div>
        <div className="mt-4 md:mt-0 flex items-center gap-2">
          <span className="w-2 h-2 bg-primary rounded-full animate-pulse"></span>
          OPERATIONAL
        </div>
      </footer>
    </div>
  );
}
