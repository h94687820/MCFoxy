import { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";
import { Plus, ArrowRight, Activity, Terminal } from "lucide-react";
import { useListProjects, useCreateProject, getListProjectsQueryKey } from "@workspace/api-client-react";
import { queryClient } from "@/lib/query-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

export default function DashboardPage() {
  const { data: projects, isLoading } = useListProjects();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  
  const createProject = useCreateProject();

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    createProject.mutate({ data: { name, description } }, {
      onSuccess: () => {
        toast.success("Project initialized successfully");
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() });
        setIsCreateOpen(false);
        setName("");
        setDescription("");
      },
      onError: () => {
        toast.error("Failed to initialize project");
      }
    });
  };

  return (
    <div className="flex flex-col h-full bg-accent/20">
      <header className="border-b-2 border-border p-6 md:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6 bg-background">
        <div>
          <h1 className="text-4xl font-black uppercase tracking-tighter mb-1 flex items-center gap-3">
            <Terminal className="w-8 h-8 text-primary" />
            Projects
          </h1>
          <p className="font-mono text-sm text-muted-foreground">Manage your Forge deployments</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="shadow-[4px_4px_0px_0px_rgba(0,0,0,0.2)]">
              <Plus className="w-4 h-4 mr-2" />
              New Project
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Initialize Project</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-6 pt-4">
              <div className="space-y-3">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Project Name</label>
                <Input 
                  value={name} 
                  onChange={(e) => setName(e.target.value)} 
                  placeholder="e.g. My Awesome App" 
                  autoFocus
                />
              </div>
              <div className="space-y-3">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Description (Optional)</label>
                <Input 
                  value={description} 
                  onChange={(e) => setDescription(e.target.value)} 
                  placeholder="What does this do?" 
                />
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createProject.isPending || !name.trim()} className="w-full sm:w-auto">
                  {createProject.isPending ? "Deploying..." : "Create Project"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </header>

      <div className="p-6 md:p-8 flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <Card key={i} className="animate-pulse h-40 bg-card border-border shadow-none" />
            ))}
          </div>
        ) : !projects?.length ? (
          <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto py-12">
            <div className="w-20 h-20 border-2 border-border bg-card flex items-center justify-center mb-8 shadow-[6px_6px_0px_0px_rgba(0,0,0,0.1)]">
              <Activity className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-2xl font-black uppercase tracking-tight mb-3">No Deployments</h3>
            <p className="font-mono text-sm text-muted-foreground mb-8 leading-relaxed">
              You haven't initialized any projects yet. Create your first project to provision API keys and database access.
            </p>
            <Button onClick={() => setIsCreateOpen(true)} className="shadow-[4px_4px_0px_0px_rgba(0,0,0,0.2)]">
              Initialize Project
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Link key={project.id} href={`/projects/${project.id}`} className="group block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2">
                <Card className="h-full transition-all group-hover:-translate-y-1 group-hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,0.2)] group-active:translate-y-0 group-active:shadow-[2px_2px_0px_0px_rgba(0,0,0,0.2)] cursor-pointer">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="truncate pr-4 flex-1">{project.name}</CardTitle>
                      <ArrowRight className="w-5 h-5 text-primary opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all shrink-0" />
                    </div>
                  </CardHeader>
                  <CardContent className="flex flex-col justify-between h-[calc(100%-72px)]">
                    <p className="font-mono text-sm text-muted-foreground line-clamp-2 mb-6 h-10">
                      {project.description || <span className="opacity-50 italic">No description provided.</span>}
                    </p>
                    <div className="flex items-center pt-4 border-t-2 border-border/50 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                      <div className="w-2 h-2 rounded-full bg-primary mr-2"></div>
                      Deployed {format(new Date(project.createdAt), 'MMM d, yyyy')}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
