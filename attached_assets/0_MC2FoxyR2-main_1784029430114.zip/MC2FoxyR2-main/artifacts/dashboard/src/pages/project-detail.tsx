import { useState, useMemo, useRef } from "react";
import { Link } from "wouter";
import { format } from "date-fns";
import { 
  Terminal, Key, Users, Database, Activity, Plus, Trash2, Copy, Check, 
  ChevronLeft, LayoutDashboard, ShieldAlert, HardDrive, Upload, FileIcon
} from "lucide-react";
import { 
  useGetProject, useGetProjectStats, useListApiKeys, useCreateApiKey, 
  useDeleteApiKey, useListEndUsers, useDeleteEndUser, useListDataRecords, 
  useDeleteDataRecord, useListProjectFiles, useDeleteProjectFile,
  getListApiKeysQueryKey, getListEndUsersQueryKey, 
  getListDataRecordsQueryKey, getGetProjectStatsQueryKey, getListProjectFilesQueryKey
} from "@workspace/api-client-react";
import { queryClient } from "@/lib/query-client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function ProjectDetailPage({ projectId }: { projectId: string }) {
  const pId = parseInt(projectId, 10);
  
  const { data: project, isLoading: isProjectLoading } = useGetProject(pId);
  const { data: stats } = useGetProjectStats(pId);
  
  if (isProjectLoading) {
    return <div className="p-8 font-mono text-muted-foreground animate-pulse">Loading project configuration...</div>;
  }
  
  if (!project) {
    return <div className="p-8 font-mono text-destructive font-bold">Project not found.</div>;
  }

  return (
    <div className="flex flex-col h-full bg-accent/20">
      <header className="border-b-2 border-border p-6 md:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6 bg-background">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 font-bold uppercase tracking-wider text-xs">
              <ChevronLeft className="w-4 h-4" />
              Projects
            </Link>
          </div>
          <h1 className="text-4xl font-black uppercase tracking-tighter mb-1 flex items-center gap-3 text-balance">
            {project.name}
          </h1>
          <p className="font-mono text-sm text-muted-foreground flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse inline-block" />
            ID: {project.id} • Deployed {format(new Date(project.createdAt), 'MMM d, yyyy')}
          </p>
        </div>
      </header>

      <div className="p-6 md:p-8 flex-1 overflow-y-auto">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="mb-8 w-full justify-start overflow-x-auto h-auto p-1 py-1">
            <TabsTrigger value="overview" className="flex items-center gap-2 px-6"><Activity className="w-4 h-4" /> Overview</TabsTrigger>
            <TabsTrigger value="keys" className="flex items-center gap-2 px-6"><Key className="w-4 h-4" /> API Keys</TabsTrigger>
            <TabsTrigger value="database" className="flex items-center gap-2 px-6"><Database className="w-4 h-4" /> Database</TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2 px-6"><Users className="w-4 h-4" /> Users</TabsTrigger>
            <TabsTrigger value="files" className="flex items-center gap-2 px-6"><HardDrive className="w-4 h-4" /> Files</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard title="API Keys" value={stats?.apiKeyCount ?? 0} icon={<Key className="w-6 h-6" />} />
              <StatCard title="End Users" value={stats?.endUserCount ?? 0} icon={<Users className="w-6 h-6" />} />
              <StatCard title="Data Collections" value={stats?.collectionCount ?? 0} icon={<LayoutDashboard className="w-6 h-6" />} />
              <StatCard title="Total Records" value={stats?.recordCount ?? 0} icon={<Database className="w-6 h-6" />} />
            </div>

            <Card className="max-w-4xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Terminal className="w-5 h-5 text-primary" /> Quick Start</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-mono text-sm text-muted-foreground mb-6 leading-relaxed">
                  اربط موقعك مباشرة بهذه المنصة كبديل لـ R2 أو Supabase. أرسل مفتاح API في الهيدر <code className="bg-muted px-1.5 py-0.5 border-2 border-border/50 text-foreground font-bold">X-API-Key</code>.
                </p>

                <div className="space-y-6">
                  {/* Auth */}
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">① تسجيل / دخول المستخدمين</p>
                    <div className="bg-foreground text-background font-mono text-xs p-4 overflow-x-auto border-2 border-border">
                      <pre className="leading-loose whitespace-pre-wrap">{`const BASE = '${window.location.origin}/api';
const KEY  = 'YOUR_API_KEY';
const h    = { 'X-API-Key': KEY, 'Content-Type': 'application/json' };

// تسجيل مستخدم جديد
const { token } = await fetch(BASE+'/v1/auth/register', {
  method:'POST', headers:h,
  body: JSON.stringify({ email:'user@example.com', password:'12345678' })
}).then(r=>r.json());`}</pre>
                    </div>
                  </div>

                  {/* Data */}
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">② حفظ وجلب البيانات (مع فلترة وترتيب)</p>
                    <div className="bg-foreground text-background font-mono text-xs p-4 overflow-x-auto border-2 border-border">
                      <pre className="leading-loose whitespace-pre-wrap">{`// حفظ سجل (يُحفظ _ownerId تلقائياً إذا أرسلت token)
await fetch(BASE+'/v1/data/mods', {
  method:'POST',
  headers: { ...h, 'Authorization':'Bearer '+token },
  body: JSON.stringify({ data:{ name:'CoolMod', version:'1.0', status:'published' } })
});

// جلب مع فلترة + ترتيب + pagination
const result = await fetch(
  BASE+'/v1/data/mods?where.status=published&orderBy=createdAt&order=desc&limit=20&offset=0',
  { headers: h }
).then(r=>r.json());
// result = { data:[...], total:42, limit:20, offset:0 }

// جلب سجلاتي أنا فقط
const mine = await fetch(BASE+'/v1/data/mods?ownedBy=me', {
  headers: { ...h, 'Authorization':'Bearer '+token }
}).then(r=>r.json());`}</pre>
                    </div>
                  </div>

                  {/* Files */}
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest text-primary mb-2">③ رفع ملف والحصول على رابط تحميل مباشر</p>
                    <div className="bg-foreground text-background font-mono text-xs p-4 overflow-x-auto border-2 border-border">
                      <pre className="leading-loose whitespace-pre-wrap">{`// الخطوة 1: طلب رابط الرفع
const { uploadURL, downloadUrl } = await fetch(BASE+'/v1/storage/upload', {
  method:'POST', headers:h,
  body: JSON.stringify({ name:'mymod.jar', size:file.size, contentType:'application/java-archive' })
}).then(r=>r.json());

// الخطوة 2: رفع الملف مباشرة إلى GCS
await fetch(uploadURL, { method:'PUT', body:file });

// downloadUrl جاهز للاستخدام مباشرة في موقعك!
// مثال: https://your-app.replit.app/api/storage/objects/uploads/abc123`}</pre>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="keys">
            <ApiKeysPanel projectId={pId} />
          </TabsContent>

          <TabsContent value="database">
            <DatabasePanel projectId={pId} />
          </TabsContent>

          <TabsContent value="users">
            <UsersPanel projectId={pId} />
          </TabsContent>

          <TabsContent value="files">
            <FilesPanel projectId={pId} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string; value: number; icon: React.ReactNode }) {
  return (
    <Card className="flex flex-col border-b-4 border-b-primary">
      <CardHeader className="flex flex-row items-center justify-between pb-2 bg-transparent border-none">
        <CardTitle className="text-sm text-muted-foreground font-bold">{title}</CardTitle>
        <div className="text-primary/40">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-4xl font-black">{value}</div>
      </CardContent>
    </Card>
  );
}

// --- API Keys Panel ---

function ApiKeysPanel({ projectId }: { projectId: number }) {
  const { data: keys, isLoading } = useListApiKeys(projectId);
  const createKey = useCreateApiKey();
  const deleteKey = useDeleteApiKey();
  
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [newSecret, setNewSecret] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    
    createKey.mutate({ projectId, data: { name } }, {
      onSuccess: (data) => {
        setNewSecret(data.secret);
        queryClient.invalidateQueries({ queryKey: getListApiKeysQueryKey(projectId) });
        queryClient.invalidateQueries({ queryKey: getGetProjectStatsQueryKey(projectId) });
      },
      onError: () => toast.error("Failed to generate API key")
    });
  };

  const handleCopy = () => {
    if (!newSecret) return;
    navigator.clipboard.writeText(newSecret);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCloseCreate = () => {
    setIsCreateOpen(false);
    setName("");
    setNewSecret(null);
    setCopied(false);
  };

  const handleRevoke = (keyId: number) => {
    if (!confirm("Are you sure you want to revoke this key? Any application using it will instantly lose access.")) return;
    deleteKey.mutate({ projectId, keyId }, {
      onSuccess: () => {
        toast.success("Key revoked");
        queryClient.invalidateQueries({ queryKey: getListApiKeysQueryKey(projectId) });
        queryClient.invalidateQueries({ queryKey: getGetProjectStatsQueryKey(projectId) });
      },
      onError: () => toast.error("Failed to revoke key")
    });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
        <div>
          <CardTitle>API Keys</CardTitle>
          <p className="font-mono text-sm text-muted-foreground mt-1">Manage programmatic access to your project.</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={(open) => { if (!open) handleCloseCreate(); else setIsCreateOpen(true); }}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="w-4 h-4 mr-2" /> Generate Key</Button>
          </DialogTrigger>
          <DialogContent>
            {newSecret ? (
              <div className="space-y-6 pt-4">
                <DialogHeader>
                  <DialogTitle className="text-primary flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5" /> Save Your Secret Key
                  </DialogTitle>
                  <DialogDescription className="text-foreground font-bold mt-2">
                    This is the <span className="underline">only time</span> this secret will be shown. If you lose it, you will need to generate a new key.
                  </DialogDescription>
                </DialogHeader>
                <div className="flex gap-2">
                  <Input value={newSecret} readOnly className="font-bold text-lg tracking-widest bg-muted" />
                  <Button onClick={handleCopy} variant="secondary" className="px-3 shrink-0">
                    {copied ? <Check className="w-5 h-5 text-primary" /> : <Copy className="w-5 h-5" />}
                  </Button>
                </div>
                <DialogFooter>
                  <Button onClick={handleCloseCreate} className="w-full">I have saved it</Button>
                </DialogFooter>
              </div>
            ) : (
              <form onSubmit={handleCreate} className="space-y-6 pt-4">
                <DialogHeader>
                  <DialogTitle>Generate New API Key</DialogTitle>
                </DialogHeader>
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Key Name</label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Production Frontend" autoFocus />
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={createKey.isPending || !name.trim()} className="w-full sm:w-auto">
                    {createKey.isPending ? "Generating..." : "Generate Key"}
                  </Button>
                </DialogFooter>
              </form>
            )}
          </DialogContent>
        </Dialog>
      </CardHeader>
      <div className="p-0">
        {isLoading ? (
          <div className="p-8 text-center font-mono text-muted-foreground">Loading keys...</div>
        ) : !keys?.length ? (
          <div className="p-12 text-center border-t-2 border-border bg-background/50">
            <Key className="w-12 h-12 text-muted mx-auto mb-4" />
            <p className="font-bold uppercase tracking-widest text-muted-foreground mb-2">No API Keys</p>
            <p className="font-mono text-sm text-muted-foreground">Generate a key to connect your application.</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Key Prefix</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Last Used</TableHead>
                <TableHead className="w-[100px] text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {keys.map(k => (
                <TableRow key={k.id}>
                  <TableCell className="font-bold uppercase tracking-wider text-xs">{k.name}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="font-mono lowercase tracking-normal">
                      {k.keyPrefix}...
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{format(new Date(k.createdAt), 'MMM d, yyyy')}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {k.lastUsedAt ? format(new Date(k.lastUsedAt), 'MMM d, yyyy HH:mm') : 'Never'}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => handleRevoke(k.id)}
                      disabled={deleteKey.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </Card>
  );
}

// --- Users Panel ---

function UsersPanel({ projectId }: { projectId: number }) {
  const { data: users, isLoading } = useListEndUsers(projectId);
  const deleteUser = useDeleteEndUser();

  const handleRevoke = (userId: number) => {
    if (!confirm("Delete this user? They will lose access immediately.")) return;
    deleteUser.mutate({ projectId, endUserId: userId }, {
      onSuccess: () => {
        toast.success("User deleted");
        queryClient.invalidateQueries({ queryKey: getListEndUsersQueryKey(projectId) });
        queryClient.invalidateQueries({ queryKey: getGetProjectStatsQueryKey(projectId) });
      },
      onError: () => toast.error("Failed to delete user")
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>End Users</CardTitle>
        <p className="font-mono text-sm text-muted-foreground mt-1">Users registered through your project's public API.</p>
      </CardHeader>
      <div className="p-0">
        {isLoading ? (
          <div className="p-8 text-center font-mono text-muted-foreground">Loading users...</div>
        ) : !users?.length ? (
          <div className="p-12 text-center border-t-2 border-border bg-background/50">
            <Users className="w-12 h-12 text-muted mx-auto mb-4" />
            <p className="font-bold uppercase tracking-widest text-muted-foreground mb-2">No Users Yet</p>
            <p className="font-mono text-sm text-muted-foreground">When users register via your API, they appear here.</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="w-[100px] text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map(u => (
                <TableRow key={u.id}>
                  <TableCell className="font-bold text-xs">{u.email}</TableCell>
                  <TableCell className="text-muted-foreground">{u.name || <span className="opacity-50 italic">None</span>}</TableCell>
                  <TableCell className="text-muted-foreground">{format(new Date(u.createdAt), 'MMM d, yyyy')}</TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => handleRevoke(u.id)}
                      disabled={deleteUser.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </Card>
  );
}

// --- Files Panel ---

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

function FilesPanel({ projectId }: { projectId: number }) {
  const { data: files, isLoading } = useListProjectFiles(projectId);
  const deleteFile = useDeleteProjectFile();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  const BASE_URL = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const urlRes = await fetch(`${BASE_URL}/api/projects/${projectId}/files/request-upload-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type || "application/octet-stream" }),
        credentials: "include",
      });

      if (!urlRes.ok) throw new Error("Failed to get upload URL");
      const { uploadURL } = await urlRes.json();

      const uploadRes = await fetch(uploadURL, {
        method: "PUT",
        headers: { "Content-Type": file.type || "application/octet-stream" },
        body: file,
      });

      if (!uploadRes.ok) throw new Error("Upload failed");

      toast.success(`${file.name} uploaded`);
      queryClient.invalidateQueries({ queryKey: getListProjectFilesQueryKey(projectId) });
    } catch {
      toast.error("Upload failed");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleDelete = (fileId: number, name: string) => {
    if (!confirm(`Delete "${name}" permanently?`)) return;
    deleteFile.mutate({ projectId, fileId }, {
      onSuccess: () => {
        toast.success("File deleted");
        queryClient.invalidateQueries({ queryKey: getListProjectFilesQueryKey(projectId) });
      },
      onError: () => toast.error("Failed to delete file"),
    });
  };

  const getDownloadUrl = (objectPath: string) =>
    `${BASE_URL}/api/storage${objectPath}`;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
        <div>
          <CardTitle>File Storage</CardTitle>
          <p className="font-mono text-sm text-muted-foreground mt-1">
            Upload and manage files for your project.
          </p>
        </div>
        <div>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={handleFileChange}
            disabled={isUploading}
          />
          <Button
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
          >
            <Upload className="w-4 h-4 mr-2" />
            {isUploading ? "Uploading..." : "Upload File"}
          </Button>
        </div>
      </CardHeader>
      <div className="p-0">
        {isLoading ? (
          <div className="p-8 text-center font-mono text-muted-foreground">Loading files...</div>
        ) : !files?.length ? (
          <div className="p-12 text-center border-t-2 border-border bg-background/50">
            <HardDrive className="w-12 h-12 text-muted mx-auto mb-4" />
            <p className="font-bold uppercase tracking-widest text-muted-foreground mb-2">No Files Yet</p>
            <p className="font-mono text-sm text-muted-foreground">
              Upload mod files here, or use your API key to upload programmatically.
            </p>
            <p className="font-mono text-xs text-muted-foreground mt-3 bg-muted p-2 inline-block border border-border">
              POST /api/v1/storage/upload
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>File Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>Uploaded By</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {files.map(f => (
                <TableRow key={f.id}>
                  <TableCell className="font-mono text-sm flex items-center gap-2">
                    <FileIcon className="w-4 h-4 text-primary shrink-0" />
                    <a
                      href={getDownloadUrl(f.objectPath)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:underline text-foreground font-bold"
                    >
                      {f.name}
                    </a>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="font-mono text-xs lowercase">
                      {f.contentType.split("/")[1] ?? f.contentType}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground font-mono text-xs">
                    {formatBytes(f.size)}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-xs">
                    {f.uploadedBy || <span className="opacity-40 italic">dashboard</span>}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {format(new Date(f.createdAt), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => handleDelete(f.id, f.name)}
                      disabled={deleteFile.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </Card>
  );
}

// --- Database Panel ---

function DatabasePanel({ projectId }: { projectId: number }) {
  const { data: records, isLoading } = useListDataRecords(projectId);
  const deleteRecord = useDeleteDataRecord();
  const [activeCollection, setActiveCollection] = useState<string | null>(null);

  const collections = useMemo(() => {
    if (!records) return [];
    const cols = Array.from(new Set(records.map(r => r.collection)));
    return cols.sort();
  }, [records]);

  // Set default active collection if null and collections exist
  if (collections.length > 0 && !activeCollection) {
    setActiveCollection(collections[0]);
  }

  const filteredRecords = useMemo(() => {
    if (!records || !activeCollection) return [];
    return records.filter(r => r.collection === activeCollection).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [records, activeCollection]);

  const handleDelete = (recordId: number) => {
    if (!confirm("Delete this record permanently?")) return;
    deleteRecord.mutate({ projectId, recordId }, {
      onSuccess: () => {
        toast.success("Record deleted");
        queryClient.invalidateQueries({ queryKey: getListDataRecordsQueryKey(projectId) });
        queryClient.invalidateQueries({ queryKey: getGetProjectStatsQueryKey(projectId) });
      },
      onError: () => toast.error("Failed to delete record")
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Data Explorer</CardTitle>
        <p className="font-mono text-sm text-muted-foreground mt-1">Browse records across your collections.</p>
      </CardHeader>
      <div className="p-0 border-t-2 border-border flex flex-col md:flex-row min-h-[400px]">
        {isLoading ? (
          <div className="p-8 w-full text-center font-mono text-muted-foreground">Loading database...</div>
        ) : !records?.length ? (
          <div className="p-12 w-full text-center bg-background/50">
            <Database className="w-12 h-12 text-muted mx-auto mb-4" />
            <p className="font-bold uppercase tracking-widest text-muted-foreground mb-2">Database Empty</p>
            <p className="font-mono text-sm text-muted-foreground">Push data via the API to automatically create collections.</p>
          </div>
        ) : (
          <>
            <div className="w-full md:w-48 xl:w-64 border-b-2 md:border-b-0 md:border-r-2 border-border bg-background/50 p-4 shrink-0">
              <h4 className="font-bold uppercase tracking-wider text-xs text-muted-foreground mb-3">Collections</h4>
              <div className="flex flex-col gap-1">
                {collections.map(col => (
                  <button
                    key={col}
                    onClick={() => setActiveCollection(col)}
                    className={`text-left px-3 py-2 font-mono text-sm transition-colors border-2 ${
                      activeCollection === col 
                        ? 'bg-primary text-primary-foreground border-primary font-bold shadow-[2px_2px_0px_0px_rgba(0,0,0,0.2)]' 
                        : 'border-transparent hover:border-border text-foreground'
                    }`}
                  >
                    {col}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex-1 overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">ID</TableHead>
                    <TableHead>Document Data</TableHead>
                    <TableHead className="w-[150px]">Created</TableHead>
                    <TableHead className="w-[80px] text-right"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map(r => (
                    <TableRow key={r.id}>
                      <TableCell>
                        <Badge variant="outline">#{r.id}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="max-h-32 overflow-y-auto bg-muted p-2 border-2 border-border/50 text-xs">
                          <pre>{JSON.stringify(r.data, null, 2)}</pre>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {format(new Date(r.createdAt), 'MMM d, yy')}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleDelete(r.id)}
                          disabled={deleteRecord.isPending}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {filteredRecords.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center font-mono text-muted-foreground">
                        No records in this collection.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </>
        )}
      </div>
    </Card>
  );
}
