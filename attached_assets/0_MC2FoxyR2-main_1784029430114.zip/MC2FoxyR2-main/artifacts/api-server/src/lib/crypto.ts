import { randomBytes, createHash, scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

/** Hashes an API key secret for storage. API keys are high-entropy random
 * strings (not user-chosen passwords), so a fast SHA-256 digest is enough —
 * no need for a slow KDF like scrypt/bcrypt here. */
export function hashApiKeySecret(secret: string): string {
  return createHash("sha256").update(secret).digest("hex");
}

/** Generates a new API key: a public prefix (safe to display/log) and the
 * plaintext secret (shown to the developer exactly once). */
export function generateApiKey(): { keyPrefix: string; secret: string } {
  const raw = randomBytes(24).toString("base64url");
  const secret = `bk_live_${raw}`;
  const keyPrefix = secret.slice(0, 14);
  return { keyPrefix, secret };
}

/** Hashes an end user's password with scrypt + a random salt. Format:
 * "<saltHex>:<hashHex>" so verification doesn't need a separate column. */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(
  password: string,
  stored: string,
): Promise<boolean> {
  const [salt, hashHex] = stored.split(":");
  if (!salt || !hashHex) return false;
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  const storedBuf = Buffer.from(hashHex, "hex");
  if (derived.length !== storedBuf.length) return false;
  return timingSafeEqual(derived, storedBuf);
}
