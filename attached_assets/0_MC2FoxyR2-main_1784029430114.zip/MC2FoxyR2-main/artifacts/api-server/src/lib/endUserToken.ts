import { createHmac, timingSafeEqual } from "crypto";

/**
 * Lightweight signed bearer token for end users of a project's public v1 API.
 * Not a full JWT — just an HMAC-signed JSON payload keyed off SESSION_SECRET,
 * scoped to a single project so a token minted for one project can't be used
 * against another.
 */

interface EndUserTokenPayload {
  endUserId: number;
  projectId: number;
  iat: number;
}

function getSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    throw new Error("SESSION_SECRET must be set to sign end user tokens.");
  }
  return secret;
}

function sign(data: string): string {
  return createHmac("sha256", getSecret()).update(data).digest("base64url");
}

export function signEndUserToken(payload: {
  endUserId: number;
  projectId: number;
}): string {
  const body: EndUserTokenPayload = { ...payload, iat: Date.now() };
  const encodedBody = Buffer.from(JSON.stringify(body)).toString("base64url");
  const signature = sign(encodedBody);
  return `${encodedBody}.${signature}`;
}

export function verifyEndUserToken(
  token: string,
): EndUserTokenPayload | null {
  const [encodedBody, signature] = token.split(".");
  if (!encodedBody || !signature) return null;

  const expectedSignature = sign(encodedBody);
  const sigBuf = Buffer.from(signature);
  const expectedBuf = Buffer.from(expectedSignature);
  if (
    sigBuf.length !== expectedBuf.length ||
    !timingSafeEqual(sigBuf, expectedBuf)
  ) {
    return null;
  }

  try {
    const body = JSON.parse(
      Buffer.from(encodedBody, "base64url").toString("utf8"),
    ) as EndUserTokenPayload;
    if (
      typeof body.endUserId !== "number" ||
      typeof body.projectId !== "number"
    ) {
      return null;
    }
    return body;
  } catch {
    return null;
  }
}
