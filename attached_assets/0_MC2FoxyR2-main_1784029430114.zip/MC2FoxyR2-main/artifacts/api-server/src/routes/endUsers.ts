import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, endUsersTable } from "@workspace/db";
import { ListEndUsersResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { loadOwnedProject, parseId } from "./projects";

const router: IRouter = Router();

router.use(requireAuth);

router.get("/projects/:projectId/endUsers", async (req, res): Promise<void> => {
  const project = await loadOwnedProject(req);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const rows = await db
    .select()
    .from(endUsersTable)
    .where(eq(endUsersTable.projectId, project.id));

  res.json(ListEndUsersResponse.parse(rows));
});

router.delete(
  "/projects/:projectId/endUsers/:endUserId",
  async (req, res): Promise<void> => {
    const project = await loadOwnedProject(req);
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }

    const endUserId = parseId(req.params.endUserId);
    await db
      .delete(endUsersTable)
      .where(
        and(eq(endUsersTable.id, endUserId), eq(endUsersTable.projectId, project.id)),
      );

    res.status(204).end();
  },
);

export default router;
