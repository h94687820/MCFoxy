import { Router, type IRouter, type Request } from "express";
import { eq, and } from "drizzle-orm";
import { db, filesTable } from "@workspace/db";
import { apiKeyAuth } from "../middlewares/apiKeyAuth";
import { ObjectStorageService, MAX_UPLOAD_SIZE_BYTES } from "../lib/objectStorage";
import { z } from "zod";

const router: IRouter = Router();
const storage = new ObjectStorageService();

router.use(apiKeyAuth);

function getProjectId(req: Request): number {
  return (req as Request & { projectId: number }).projectId;
}

const PublicUploadBody = z.object({
  name: z.string().min(1),
  size: z.number().int().nonnegative().max(MAX_UPLOAD_SIZE_BYTES, "File exceeds maximum size of 100MB"),
  contentType: z.string().default("application/octet-stream"),
  uploadedBy: z.string().optional(),
});

// POST /v1/storage/upload — get presigned upload URL
router.post("/v1/storage/upload", async (req, res): Promise<void> => {
  const parsed = PublicUploadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { name, size, contentType, uploadedBy } = parsed.data;
  const projectId = getProjectId(req);

  // Auto-set uploadedBy from token if present
  let resolvedUploadedBy = uploadedBy;
  const header = req.header("Authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
  if (token && !resolvedUploadedBy) {
    const { verifyEndUserToken } = await import("../lib/endUserToken");
    const payload = verifyEndUserToken(token);
    if (payload && payload.projectId === projectId) {
      resolvedUploadedBy = String(payload.endUserId);
    }
  }

  const uploadURL = await storage.getObjectEntityUploadURL();
  const objectPath = storage.normalizeObjectEntityPath(uploadURL);

  const [file] = await db.insert(filesTable).values({
    projectId,
    name,
    objectPath,
    contentType,
    size,
    uploadedBy: resolvedUploadedBy ?? null,
  }).returning();

  // Public download URL — served through our API
  const host = `${req.protocol}://${req.get("host")}`;
  const downloadUrl = `${host}/api/storage${objectPath}`;

  res.json({ uploadURL, objectPath, downloadUrl, fileId: file.id });
});

// GET /v1/storage — list files for this project
// ?uploadedBy=me requires Authorization token
router.get("/v1/storage", async (req, res): Promise<void> => {
  const projectId = getProjectId(req);
  const conditions = [eq(filesTable.projectId, projectId)];

  if (req.query.uploadedBy === "me") {
    const header = req.header("Authorization");
    const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
    if (!token) {
      res.status(401).json({ error: "Authorization token required for uploadedBy=me" });
      return;
    }
    const { verifyEndUserToken } = await import("../lib/endUserToken");
    const payload = verifyEndUserToken(token);
    if (!payload || payload.projectId !== projectId) {
      res.status(401).json({ error: "Invalid token" });
      return;
    }
    conditions.push(eq(filesTable.uploadedBy, String(payload.endUserId)));
  } else if (req.query.uploadedBy && typeof req.query.uploadedBy === "string") {
    conditions.push(eq(filesTable.uploadedBy, req.query.uploadedBy));
  }

  const rows = await db
    .select()
    .from(filesTable)
    .where(and(...conditions))
    .orderBy(filesTable.createdAt);

  const host = `${req.protocol}://${req.get("host")}`;
  const withUrls = rows.map(f => ({
    ...f,
    downloadUrl: `${host}/api/storage${f.objectPath}`,
  }));

  res.json(withUrls);
});

// GET /v1/storage/:fileId — get single file info + download URL
router.get("/v1/storage/:fileId", async (req, res): Promise<void> => {
  const fileId = parseInt(req.params.fileId, 10);
  if (isNaN(fileId)) {
    res.status(400).json({ error: "Invalid file ID" });
    return;
  }

  const [file] = await db
    .select()
    .from(filesTable)
    .where(and(eq(filesTable.id, fileId), eq(filesTable.projectId, getProjectId(req))))
    .limit(1);

  if (!file) {
    res.status(404).json({ error: "File not found" });
    return;
  }

  const host = `${req.protocol}://${req.get("host")}`;
  res.json({ ...file, downloadUrl: `${host}/api/storage${file.objectPath}` });
});

// DELETE /v1/storage/:fileId — delete a file (owner only if uploadedBy set)
router.delete("/v1/storage/:fileId", async (req, res): Promise<void> => {
  const fileId = parseInt(req.params.fileId, 10);
  if (isNaN(fileId)) {
    res.status(400).json({ error: "Invalid file ID" });
    return;
  }

  const projectId = getProjectId(req);
  const [file] = await db
    .select()
    .from(filesTable)
    .where(and(eq(filesTable.id, fileId), eq(filesTable.projectId, projectId)))
    .limit(1);

  if (!file) {
    res.status(404).json({ error: "File not found" });
    return;
  }

  // Ownership check if uploadedBy is set
  if (file.uploadedBy) {
    const header = req.header("Authorization");
    const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
    if (!token) {
      res.status(401).json({ error: "Authorization token required to delete this file" });
      return;
    }
    const { verifyEndUserToken } = await import("../lib/endUserToken");
    const payload = verifyEndUserToken(token);
    if (!payload || String(payload.endUserId) !== file.uploadedBy) {
      res.status(403).json({ error: "You do not own this file" });
      return;
    }
  }

  await db.delete(filesTable).where(eq(filesTable.id, fileId));
  res.status(204).end();
});

export default router;
