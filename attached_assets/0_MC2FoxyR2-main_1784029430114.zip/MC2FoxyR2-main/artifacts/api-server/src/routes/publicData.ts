import { Router, type IRouter, type Request } from "express";
import { eq, and, asc, desc, sql } from "drizzle-orm";
import { db, recordsTable } from "@workspace/db";
import {
  CreatePublicRecordBody,
  CreatePublicRecordResponse,
  GetPublicRecordResponse,
  UpdatePublicRecordBody,
  UpdatePublicRecordResponse,
  IncrementPublicRecordFieldBody,
  IncrementPublicRecordFieldResponse,
} from "@workspace/api-zod";
import { apiKeyAuth } from "../middlewares/apiKeyAuth";
import { endUserAuth } from "../middlewares/endUserAuth";
import { parseId } from "./projects";

const router: IRouter = Router();

router.use(apiKeyAuth);

function getProjectId(req: Request): number {
  return (req as Request & { projectId: number }).projectId;
}

function getEndUserId(req: Request): number | undefined {
  return (req as Request & { endUserId?: number }).endUserId;
}

function getCollection(req: Request): string {
  const raw = req.params.collection;
  return Array.isArray(raw) ? raw[0] : raw;
}

// GET /v1/data/:collection
// Query params: limit, offset, orderBy, order (asc/desc), ownedBy (true = only my records)
router.get("/v1/data/:collection", async (req, res): Promise<void> => {
  const projectId = getProjectId(req);
  const collection = getCollection(req);

  const limit = Math.min(parseInt(String(req.query.limit ?? "50"), 10) || 50, 500);
  const offset = parseInt(String(req.query.offset ?? "0"), 10) || 0;
  const orderField = String(req.query.orderBy ?? "createdAt");
  const orderDir = String(req.query.order ?? "desc").toLowerCase() === "asc" ? "asc" : "desc";
  // Sorting by a numeric field inside `data`, e.g. orderBy=data.downloads — useful for
  // "most downloaded" / "top rated" style listings.
  const dataOrderField = orderField.startsWith("data.") ? orderField.slice(5) : undefined;

  // Build where conditions
  const conditions = [
    eq(recordsTable.projectId, projectId),
    eq(recordsTable.collection, collection),
  ];

  // Filter by data fields: any query param prefixed with "where." e.g. ?where.status=published
  const dataFilters: Record<string, string> = {};
  for (const [key, val] of Object.entries(req.query)) {
    if (key.startsWith("where.") && typeof val === "string") {
      dataFilters[key.slice(6)] = val;
    }
  }
  for (const [field, value] of Object.entries(dataFilters)) {
    conditions.push(
      sql`${recordsTable.data}->>${field} = ${value}`
    );
  }

  // Ownership filter: ?ownedBy=me requires Authorization token
  const ownedByMe = req.query.ownedBy === "me";
  if (ownedByMe) {
    // Try to extract end user from token (optional auth)
    const header = req.header("Authorization");
    const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
    if (token) {
      const { verifyEndUserToken } = await import("../lib/endUserToken");
      const payload = verifyEndUserToken(token);
      if (payload && payload.projectId === projectId) {
        conditions.push(
          sql`${recordsTable.data}->>'_ownerId' = ${String(payload.endUserId)}`
        );
      } else {
        res.status(401).json({ error: "Invalid token for ownership filter" });
        return;
      }
    } else {
      res.status(401).json({ error: "Authorization token required for ownedBy=me" });
      return;
    }
  }

  // Order by
  const orderExpr = dataOrderField
    ? (orderDir === "asc"
        ? asc(sql`(${recordsTable.data}->>${dataOrderField})::numeric`)
        : desc(sql`(${recordsTable.data}->>${dataOrderField})::numeric`))
    : orderField === "updatedAt"
      ? (orderDir === "asc" ? asc(recordsTable.updatedAt) : desc(recordsTable.updatedAt))
      : (orderDir === "asc" ? asc(recordsTable.createdAt) : desc(recordsTable.createdAt));

  const rows = await db
    .select()
    .from(recordsTable)
    .where(and(...conditions))
    .orderBy(orderExpr)
    .limit(limit)
    .offset(offset);

  // Total count for pagination
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(recordsTable)
    .where(and(...conditions));

  res.json({ data: rows, total: count, limit, offset });
});

// POST /v1/data/:collection
// If Authorization header present, auto-sets _ownerId in data
router.post("/v1/data/:collection", async (req, res): Promise<void> => {
  const parsed = CreatePublicRecordBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid record body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  // Auto-set _ownerId if end user token present
  let ownerId: number | undefined;
  const header = req.header("Authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
  if (token) {
    const { verifyEndUserToken } = await import("../lib/endUserToken");
    const payload = verifyEndUserToken(token);
    if (payload && payload.projectId === getProjectId(req)) {
      ownerId = payload.endUserId;
    }
  }

  const data = { ...parsed.data.data };
  if (ownerId !== undefined) {
    data._ownerId = String(ownerId);
  }

  const [row] = await db
    .insert(recordsTable)
    .values({
      projectId: getProjectId(req),
      collection: getCollection(req),
      data,
    })
    .returning();

  res.status(201).json(CreatePublicRecordResponse.parse(row));
});

async function loadScopedRecord(req: Request) {
  const recordId = parseId(req.params.recordId);
  const [row] = await db
    .select()
    .from(recordsTable)
    .where(
      and(
        eq(recordsTable.id, recordId),
        eq(recordsTable.projectId, getProjectId(req)),
        eq(recordsTable.collection, getCollection(req)),
      ),
    )
    .limit(1);
  return row;
}

router.get(
  "/v1/data/:collection/:recordId",
  async (req, res): Promise<void> => {
    const row = await loadScopedRecord(req);
    if (!row) {
      res.status(404).json({ error: "Record not found" });
      return;
    }
    res.json(GetPublicRecordResponse.parse(row));
  },
);

// PATCH — only owner can update their own record (if _ownerId set)
router.patch(
  "/v1/data/:collection/:recordId",
  async (req, res): Promise<void> => {
    const existing = await loadScopedRecord(req);
    if (!existing) {
      res.status(404).json({ error: "Record not found" });
      return;
    }

    // Ownership check if record has _ownerId
    const ownerId = (existing.data as Record<string, unknown>)._ownerId;
    if (ownerId !== undefined) {
      const header = req.header("Authorization");
      const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
      if (!token) {
        res.status(401).json({ error: "Authorization token required to update this record" });
        return;
      }
      const { verifyEndUserToken } = await import("../lib/endUserToken");
      const payload = verifyEndUserToken(token);
      if (!payload || String(payload.endUserId) !== String(ownerId)) {
        res.status(403).json({ error: "You do not own this record" });
        return;
      }
    }

    const parsed = UpdatePublicRecordBody.safeParse(req.body);
    if (!parsed.success) {
      req.log.warn({ errors: parsed.error.message }, "Invalid record update");
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const [row] = await db
      .update(recordsTable)
      .set({ data: { ...(existing.data as object), ...parsed.data.data }, updatedAt: new Date() })
      .where(eq(recordsTable.id, existing.id))
      .returning();

    res.json(UpdatePublicRecordResponse.parse(row));
  },
);

// DELETE — only owner can delete their own record (if _ownerId set)
router.delete(
  "/v1/data/:collection/:recordId",
  async (req, res): Promise<void> => {
    const existing = await loadScopedRecord(req);
    if (!existing) {
      res.status(404).json({ error: "Record not found" });
      return;
    }

    const ownerId = (existing.data as Record<string, unknown>)._ownerId;
    if (ownerId !== undefined) {
      const header = req.header("Authorization");
      const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
      if (!token) {
        res.status(401).json({ error: "Authorization token required to delete this record" });
        return;
      }
      const { verifyEndUserToken } = await import("../lib/endUserToken");
      const payload = verifyEndUserToken(token);
      if (!payload || String(payload.endUserId) !== String(ownerId)) {
        res.status(403).json({ error: "You do not own this record" });
        return;
      }
    }

    await db.delete(recordsTable).where(eq(recordsTable.id, existing.id));
    res.status(204).end();
  },
);

// POST /v1/data/:collection/:recordId/increment — atomically bump a numeric field.
// Useful for counters like download counts where two concurrent requests must not clobber each other.
router.post(
  "/v1/data/:collection/:recordId/increment",
  async (req, res): Promise<void> => {
    const existing = await loadScopedRecord(req);
    if (!existing) {
      res.status(404).json({ error: "Record not found" });
      return;
    }

    const parsed = IncrementPublicRecordFieldBody.safeParse(req.body);
    if (!parsed.success) {
      req.log.warn({ errors: parsed.error.message }, "Invalid increment body");
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    const { field, amount = 1 } = parsed.data;

    const [row] = await db
      .update(recordsTable)
      .set({
        data: sql`jsonb_set(${recordsTable.data}, ${`{${field}}`}, to_jsonb(COALESCE((${recordsTable.data}->>${field})::numeric, 0) + ${amount}))`,
        updatedAt: new Date(),
      })
      .where(eq(recordsTable.id, existing.id))
      .returning();

    res.json(IncrementPublicRecordFieldResponse.parse(row));
  },
);

export default router;
