import { Router, type IRouter, type Request } from "express";
import { eq, and } from "drizzle-orm";
import { db, endUsersTable } from "@workspace/db";
import {
  RegisterEndUserBody,
  RegisterEndUserResponse,
  LoginEndUserBody,
  LoginEndUserResponse,
  GetCurrentEndUserResponse,
} from "@workspace/api-zod";
import { apiKeyAuth } from "../middlewares/apiKeyAuth";
import { endUserAuth } from "../middlewares/endUserAuth";
import { hashPassword, verifyPassword } from "../lib/crypto";
import { signEndUserToken } from "../lib/endUserToken";

const router: IRouter = Router();

function getProjectId(req: Request): number {
  return (req as Request & { projectId: number }).projectId;
}

router.post("/v1/auth/register", apiKeyAuth, async (req, res): Promise<void> => {
  const parsed = RegisterEndUserBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid register body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const projectId = getProjectId(req);
  const [existing] = await db
    .select()
    .from(endUsersTable)
    .where(
      and(
        eq(endUsersTable.projectId, projectId),
        eq(endUsersTable.email, parsed.data.email),
      ),
    )
    .limit(1);

  if (existing) {
    res.status(409).json({ error: "Email already registered" });
    return;
  }

  const passwordHash = await hashPassword(parsed.data.password);
  const [endUser] = await db
    .insert(endUsersTable)
    .values({
      projectId,
      email: parsed.data.email,
      passwordHash,
      name: parsed.data.name,
    })
    .returning();

  const token = signEndUserToken({ endUserId: endUser.id, projectId });
  res.status(201).json(RegisterEndUserResponse.parse({ token, endUser }));
});

router.post("/v1/auth/login", apiKeyAuth, async (req, res): Promise<void> => {
  const parsed = LoginEndUserBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid login body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const projectId = getProjectId(req);
  const [endUser] = await db
    .select()
    .from(endUsersTable)
    .where(
      and(
        eq(endUsersTable.projectId, projectId),
        eq(endUsersTable.email, parsed.data.email),
      ),
    )
    .limit(1);

  const valid =
    endUser && (await verifyPassword(parsed.data.password, endUser.passwordHash));
  if (!endUser || !valid) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  const token = signEndUserToken({ endUserId: endUser.id, projectId });
  res.json(LoginEndUserResponse.parse({ token, endUser }));
});

router.get(
  "/v1/auth/me",
  apiKeyAuth,
  endUserAuth,
  async (req, res): Promise<void> => {
    const endUserId = (req as Request & { endUserId: number }).endUserId;
    const [endUser] = await db
      .select()
      .from(endUsersTable)
      .where(eq(endUsersTable.id, endUserId))
      .limit(1);

    if (!endUser) {
      res.status(404).json({ error: "End user not found" });
      return;
    }

    res.json(GetCurrentEndUserResponse.parse(endUser));
  },
);

export default router;
