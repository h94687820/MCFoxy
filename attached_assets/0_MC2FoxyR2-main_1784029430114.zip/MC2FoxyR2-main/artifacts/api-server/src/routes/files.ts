import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, filesTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { ObjectStorageService } from "../lib/objectStorage";
import { parseId } from "./projects";
import { z } from "zod";

const router: IRouter = Router();
const storage = new ObjectStorageService();

const UploadUrlBody = z.object({
  name: z.string().min(1),
  size: z.number().int().nonnegative(),
  contentType: z.string().default("application/octet-stream"),
});

router.post(
  "/projects/:projectId/files/request-upload-url",
  requireAuth,
  async (req, res): Promise<void> => {
    const projectId = parseId(req.params.projectId);
    const parsed = UploadUrlBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const { name, size, contentType } = parsed.data;

    const uploadURL = await storage.getObjectEntityUploadURL();
    const objectPath = storage.normalizeObjectEntityPath(uploadURL);

    await db.insert(filesTable).values({ projectId, name, objectPath, contentType, size });

    res.json({ uploadURL, objectPath });
  },
);

router.get(
  "/projects/:projectId/files",
  requireAuth,
  async (req, res): Promise<void> => {
    const projectId = parseId(req.params.projectId);
    const rows = await db
      .select()
      .from(filesTable)
      .where(eq(filesTable.projectId, projectId))
      .orderBy(filesTable.createdAt);

    res.json(rows);
  },
);

router.delete(
  "/projects/:projectId/files/:fileId",
  requireAuth,
  async (req, res): Promise<void> => {
    const projectId = parseId(req.params.projectId);
    const fileId = parseId(req.params.fileId);

    const [file] = await db
      .select()
      .from(filesTable)
      .where(and(eq(filesTable.id, fileId), eq(filesTable.projectId, projectId)))
      .limit(1);

    if (!file) {
      res.status(404).json({ error: "File not found" });
      return;
    }

    await db.delete(filesTable).where(eq(filesTable.id, fileId));
    res.status(204).end();
  },
);

export default router;
