import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, apiKeysTable } from "@workspace/db";
import {
  ListApiKeysResponse,
  CreateApiKeyBody,
  CreateApiKeyResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { loadOwnedProject, parseId } from "./projects";
import { generateApiKey, hashApiKeySecret } from "../lib/crypto";

const router: IRouter = Router();

router.use(requireAuth);

router.get("/projects/:projectId/apiKeys", async (req, res): Promise<void> => {
  const project = await loadOwnedProject(req);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const rows = await db
    .select()
    .from(apiKeysTable)
    .where(eq(apiKeysTable.projectId, project.id));

  res.json(ListApiKeysResponse.parse(rows));
});

router.post("/projects/:projectId/apiKeys", async (req, res): Promise<void> => {
  const project = await loadOwnedProject(req);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const parsed = CreateApiKeyBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid API key body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { keyPrefix, secret } = generateApiKey();
  const [row] = await db
    .insert(apiKeysTable)
    .values({
      projectId: project.id,
      name: parsed.data.name,
      keyPrefix,
      hashedSecret: hashApiKeySecret(secret),
    })
    .returning();

  res
    .status(201)
    .json(CreateApiKeyResponse.parse({ ...row, secret }));
});

router.delete(
  "/projects/:projectId/apiKeys/:keyId",
  async (req, res): Promise<void> => {
    const project = await loadOwnedProject(req);
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }

    const keyId = parseId(req.params.keyId);
    await db
      .delete(apiKeysTable)
      .where(and(eq(apiKeysTable.id, keyId), eq(apiKeysTable.projectId, project.id)));

    res.status(204).end();
  },
);

export default router;
