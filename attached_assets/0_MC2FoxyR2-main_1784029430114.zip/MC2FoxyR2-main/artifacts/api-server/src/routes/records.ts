import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, recordsTable } from "@workspace/db";
import { ListDataRecordsResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { loadOwnedProject, parseId } from "./projects";

const router: IRouter = Router();

router.use(requireAuth);

router.get("/projects/:projectId/records", async (req, res): Promise<void> => {
  const project = await loadOwnedProject(req);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const rows = await db
    .select()
    .from(recordsTable)
    .where(eq(recordsTable.projectId, project.id));

  res.json(ListDataRecordsResponse.parse(rows));
});

router.delete(
  "/projects/:projectId/records/:recordId",
  async (req, res): Promise<void> => {
    const project = await loadOwnedProject(req);
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }

    const recordId = parseId(req.params.recordId);
    await db
      .delete(recordsTable)
      .where(
        and(eq(recordsTable.id, recordId), eq(recordsTable.projectId, project.id)),
      );

    res.status(204).end();
  },
);

export default router;
