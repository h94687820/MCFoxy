import { Router, type IRouter } from "express";
import healthRouter from "./health";
import projectsRouter from "./projects";
import apiKeysRouter from "./apiKeys";
import endUsersRouter from "./endUsers";
import recordsRouter from "./records";
import filesRouter from "./files";
import storageRouter from "./storage";
import publicAuthRouter from "./publicAuth";
import publicDataRouter from "./publicData";
import publicStorageRouter from "./publicStorage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(projectsRouter);
router.use(apiKeysRouter);
router.use(endUsersRouter);
router.use(recordsRouter);
router.use(filesRouter);
router.use(storageRouter);
router.use(publicAuthRouter);
router.use(publicDataRouter);
router.use(publicStorageRouter);

export default router;
