import { Router, type IRouter, type Request } from "express";
import { eq, and, count } from "drizzle-orm";
import { db, projectsTable, apiKeysTable, endUsersTable, recordsTable } from "@workspace/db";
import {
  ListProjectsResponse,
  CreateProjectBody,
  CreateProjectResponse,
  GetProjectResponse,
  UpdateProjectBody,
  UpdateProjectResponse,
  GetProjectStatsResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

function getUserId(req: Request): string {
  return (req as Request & { userId: string }).userId;
}

function parseId(raw: unknown): number {
  const value = Array.isArray(raw) ? raw[0] : raw;
  return parseInt(String(value), 10);
}

router.use(requireAuth);

router.get("/projects", async (req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.ownerId, getUserId(req)));

  const data = rows.map((row) => ({
    ...row,
    updatedAt: row.createdAt,
  }));
  res.json(ListProjectsResponse.parse(data));
});

router.post("/projects", async (req, res): Promise<void> => {
  const parsed = CreateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid project body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [row] = await db
    .insert(projectsTable)
    .values({ ...parsed.data, ownerId: getUserId(req) })
    .returning();

  res.status(201).json(
    CreateProjectResponse.parse({ ...row, updatedAt: row.createdAt }),
  );
});

async function loadOwnedProject(req: Request) {
  const projectId = parseId(req.params.projectId);
  const [row] = await db
    .select()
    .from(projectsTable)
    .where(
      and(eq(projectsTable.id, projectId), eq(projectsTable.ownerId, getUserId(req))),
    )
    .limit(1);
  return row;
}

router.get("/projects/:projectId", async (req, res): Promise<void> => {
  const row = await loadOwnedProject(req);
  if (!row) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  res.json(GetProjectResponse.parse({ ...row, updatedAt: row.createdAt }));
});

router.patch("/projects/:projectId", async (req, res): Promise<void> => {
  const existing = await loadOwnedProject(req);
  if (!existing) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const parsed = UpdateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid project update");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [row] = await db
    .update(projectsTable)
    .set(parsed.data)
    .where(eq(projectsTable.id, existing.id))
    .returning();

  res.json(UpdateProjectResponse.parse({ ...row, updatedAt: row.createdAt }));
});

router.delete("/projects/:projectId", async (req, res): Promise<void> => {
  const existing = await loadOwnedProject(req);
  if (!existing) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  await db.delete(projectsTable).where(eq(projectsTable.id, existing.id));
  res.status(204).end();
});

router.get("/projects/:projectId/stats", async (req, res): Promise<void> => {
  const existing = await loadOwnedProject(req);
  if (!existing) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const [[endUserCount], [apiKeyCount], recordRows] = await Promise.all([
    db
      .select({ value: count() })
      .from(endUsersTable)
      .where(eq(endUsersTable.projectId, existing.id)),
    db
      .select({ value: count() })
      .from(apiKeysTable)
      .where(eq(apiKeysTable.projectId, existing.id)),
    db
      .select({ collection: recordsTable.collection })
      .from(recordsTable)
      .where(eq(recordsTable.projectId, existing.id)),
  ]);

  const collectionCount = new Set(recordRows.map((r) => r.collection)).size;

  res.json(
    GetProjectStatsResponse.parse({
      projectId: existing.id,
      endUserCount: endUserCount?.value ?? 0,
      recordCount: recordRows.length,
      collectionCount,
      apiKeyCount: apiKeyCount?.value ?? 0,
    }),
  );
});

export default router;
export { loadOwnedProject, parseId, getUserId };
