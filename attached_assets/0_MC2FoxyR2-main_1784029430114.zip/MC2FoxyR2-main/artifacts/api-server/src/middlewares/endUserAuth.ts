import type { Request, Response, NextFunction } from "express";
import { verifyEndUserToken } from "../lib/endUserToken";

/** Protects public v1 API routes that act on behalf of a specific end user
 * (e.g. GET /v1/auth/me). Must run after `apiKeyAuth` so `req.projectId` is
 * already set; verifies the bearer token belongs to that same project. */
export function endUserAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const header = req.header("Authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7) : undefined;
  if (!token) {
    res.status(401).json({ error: "Missing Authorization bearer token" });
    return;
  }

  const payload = verifyEndUserToken(token);
  const projectId = (req as Request & { projectId?: number }).projectId;
  if (!payload || payload.projectId !== projectId) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }

  (req as Request & { endUserId: number }).endUserId = payload.endUserId;
  next();
}
