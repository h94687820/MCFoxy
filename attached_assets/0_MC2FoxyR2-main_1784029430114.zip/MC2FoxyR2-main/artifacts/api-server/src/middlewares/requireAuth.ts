import { getAuth } from "@clerk/express";
import type { Request, Response, NextFunction } from "express";

/** Protects dashboard routes: requires a signed-in Clerk session and
 * attaches the Clerk user id to `req.userId`. */
export function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const auth = getAuth(req);
  const userId = auth?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  (req as Request & { userId: string }).userId = userId;
  next();
}
