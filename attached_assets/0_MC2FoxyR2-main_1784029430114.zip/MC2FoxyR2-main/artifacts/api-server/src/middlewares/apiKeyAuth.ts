import type { Request, Response, NextFunction } from "express";
import { eq } from "drizzle-orm";
import { db, apiKeysTable } from "@workspace/db";
import { hashApiKeySecret } from "../lib/crypto";

/** Protects public v1 API routes: requires a valid `X-API-Key` header and
 * attaches the resolved `req.projectId` for the calling project. */
export async function apiKeyAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const header = req.header("X-API-Key");
  if (!header) {
    res.status(401).json({ error: "Missing X-API-Key header" });
    return;
  }

  const hashedSecret = hashApiKeySecret(header);
  const [key] = await db
    .select()
    .from(apiKeysTable)
    .where(eq(apiKeysTable.hashedSecret, hashedSecret))
    .limit(1);

  if (!key) {
    res.status(401).json({ error: "Invalid API key" });
    return;
  }

  await db
    .update(apiKeysTable)
    .set({ lastUsedAt: new Date() })
    .where(eq(apiKeysTable.id, key.id));

  (req as Request & { projectId: number }).projectId = key.projectId;
  next();
}
