---
name: BaaS platform architecture
description: Two-layer auth model for the Forge backend-as-a-service dashboard, and Orval/zod codegen pitfalls hit while building its OpenAPI spec.
---

## Two-layer auth model
This project is a Firebase-like BaaS control panel (dashboard) where developers manage "projects", each with its own API key, end users, and generic JSON records that external sites call over a public REST API.

- **Dashboard auth** (developer managing projects): Replit-managed Clerk, cookie-session based, `requireAuth` middleware reads `getAuth(req)`.
- **Public v1 API auth** (the external site's own end users): a per-project `X-API-Key` header (SHA-256 hashed at rest, prefix shown for display) resolved via `apiKeyAuth` middleware to `req.projectId`, plus a lightweight HMAC-signed bearer token (not a full JWT) for end-user sessions, signed with the existing `SESSION_SECRET` env var — no new dependency needed for either.

**Why:** these are two independent trust domains (the platform owner vs. the platform owner's own end users) and must not share a token scheme. Reusing Clerk for the public API would require every external end user to have a Clerk account, which defeats the "hosted backend for someone else's site" purpose.

**How to apply:** when extending this app, keep dashboard routes behind `requireAuth` (Clerk) and public `/v1/*` routes behind `apiKeyAuth` (+ `endUserAuth` when acting on behalf of a specific end user). Scope end-user tokens by `projectId` so a token minted for one project can't be replayed against another.

## Extending the generic public API for domain use cases (e.g. a mod/download site)
Counters (download counts), ratings/comments, and search/filter for a specific domain don't need
dedicated schemas — they're modeled as generic collections in `records`/`files` plus three additions:
`POST /v1/data/:collection/:recordId/increment` (atomic `jsonb_set` bump, avoids read-modify-write races),
`orderBy=data.<field>` support in the list endpoint (numeric cast) for "most downloaded"/"top rated" sorts,
and a `MAX_UPLOAD_SIZE_BYTES` (100MB) cap enforced in both `storage.ts` and `publicStorage.ts`.

**Why:** keeps the platform generic (any external site can define its own collections) while still
covering domain needs like a Minecraft mod site (mods collection + comments collection filtered by
`where.modId=X` + downloads counter) without new tables per use case.

## Orval/zod codegen pitfalls (this workspace's pinned zod v3.25.76)
- Do not use `format: email` in OpenAPI string schemas — Orval emits `zod.email()`, which is a zod v4 top-level API not present in this project's pinned zod v3. Causes `TS2339: Property 'email' does not exist`. Validate email format in route handlers instead.
- Avoid combining a path parameter with a query parameter on the same operation in the `zod` client output (mode: split). Orval names the query-params TS type (emitted to `generated/types/`) the same as the path-params zod object in `generated/api.ts` (both `<OperationId>Params`), causing a `TS2308` duplicate-export collision on the barrel `export *`. Workaround: avoid query params on path-scoped list endpoints (filter client-side instead), or otherwise don't mix path+query params on one operation.
- **Critical naming rule for `components/schemas`**: If a component schema name EXACTLY matches what orval auto-derives from the operationId (e.g. schema named `RequestUploadUrlBody` for operation `requestUploadUrl`), orval generates BOTH a Zod schema (`api.ts`) AND a TypeScript interface (`types/`) with the same name → `TS2308` collision. Fix: name the component schema DIFFERENTLY from the operationId pattern (e.g. `StorageUploadInput` instead of `RequestUploadUrlBody`). Orval derives the Zod schema name from the operationId; the TypeScript interface name comes from the component schema name — keep these different to avoid collision.
- `lib/api-zod/src/index.ts` is OVERWRITTEN by orval on every codegen run. Only export `export * from "./generated/api"` (the Zod schemas). Do NOT add `export * from "./generated/types"` — the types directory has interfaces that duplicate Zod schema names causing TS2308. The api-server uses Zod schemas for validation; TypeScript types are inferred from them.
- The api-server does NOT have `zod` as a direct dependency. Use `zod` from the route's own installed package (add with `pnpm --filter @workspace/api-server add zod`), NOT `zod/v4`.

## Cloudflare Worker port (`cloudflare/worker`) — standalone deploy target
A separate, self-contained port of this platform exists at `cloudflare/worker` (Hono + D1 + R2), meant to be deployed to Cloudflare independently of the Replit-hosted artifacts. It is not a Replit "artifact" and has its own `README.md` with setup/deploy steps.

**Replit-managed Clerk cannot authenticate off-Replit domains.** It relies on host-based publishable-key resolution (`publishableKeyFromHost`) and a `/api/__clerk` Frontend-API proxy that only exist on Replit's hosting infra.

**Why:** a site served from a Cloudflare Worker domain has no access to Replit's proxy/host-resolution registry, so Replit-managed Clerk keys silently fail to authenticate there.

**How to apply:** any standalone (non-Replit-hosted) deployment of a Clerk-auth'd app needs its own self-managed Clerk application with its own publishable/secret keys, wired in separately from the Replit-managed `CLERK_*`/`VITE_CLERK_PUBLISHABLE_KEY` secrets (which must stay reserved for the Replit-hosted copy). In this project that's done via distinct `CF_CLERK_PUBLISHABLE_KEY`/`CF_CLERK_SECRET_KEY` secrets consumed only by `cloudflare/worker`'s build/deploy scripts — the shared dashboard frontend source itself needs no changes, since `publishableKeyFromHost` falls back to whatever key it's given when the host isn't in Replit's registry.

## Cloudflare Worker — deployed successfully (2026-07-14)
Live at `baas-platform.mcfoxy.workers.dev`. D1 database `baas-platform-db` created and migrated; R2 intentionally left disabled by owner's choice (file-storage routes return 501) — this is a supported, permanent configuration for this deployment, not a TODO. `wrangler.toml`'s `[vars] CLERK_PUBLISHABLE_KEY` is a plain public var (not injected by any script at deploy time) — it must be manually kept in sync with the `CF_CLERK_PUBLISHABLE_KEY` secret whenever that key rotates, since the backend (`requireAuth.ts`) reads `c.env.CLERK_PUBLISHABLE_KEY` for Clerk verification.

**Why:** `requestSecrets` secret values may not be visible in a shell session that was already open before the user confirmed them — `${#VAR}` read 0 even though `viewEnvVars` showed the key existed. A **fresh** `ShellExec` call after confirmation picks it up correctly (confirmed via `wrangler whoami` succeeding only after a new shell invocation).

**How to apply:** after `requestSecrets` resolves, always issue a new ShellExec/CodeExecution call (don't reuse pre-existing shell state) before relying on the secret's env value — and verify sensitive substitutions by comparing lengths/hashes (never by eyeballing two `pk_test_...`-style strings, which look deceptively similar).
