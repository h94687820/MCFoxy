import { pgTable, text, serial, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const recordsTable = pgTable("records", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  collection: text("collection").notNull(),
  data: jsonb("data").notNull().$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type RecordRow = typeof recordsTable.$inferSelect;
