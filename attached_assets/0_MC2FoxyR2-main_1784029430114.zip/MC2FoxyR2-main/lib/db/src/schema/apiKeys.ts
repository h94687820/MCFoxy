import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { z } from "zod/v4";
import { projectsTable } from "./projects";

export const apiKeysTable = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  // Public prefix shown alongside the masked key, e.g. "bk_live_ab12".
  keyPrefix: text("key_prefix").notNull(),
  // SHA-256 hex digest of the full secret; the plaintext secret is never stored.
  hashedSecret: text("hashed_secret").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastUsedAt: timestamp("last_used_at"),
});

export const insertApiKeySchema = z.object({
  name: z.string().min(1),
});

export type InsertApiKey = z.infer<typeof insertApiKeySchema>;
export type ApiKeyRow = typeof apiKeysTable.$inferSelect;
