import { pgTable, text, serial, timestamp, integer, unique } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const endUsersTable = pgTable(
  "end_users",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id")
      .notNull()
      .references(() => projectsTable.id, { onDelete: "cascade" }),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    name: text("name"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => [unique().on(table.projectId, table.email)],
);

export type EndUserRow = typeof endUsersTable.$inferSelect;
